import React from 'react';
import { BookOpen } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';

interface ReadingGuideProps {
  language: Language;
}

export const ReadingGuide: React.FC<ReadingGuideProps> = ({ language }) => {
  const t = translations[language];

  return (
    <section id="rules-guide" className="wl-section wl-content-section">
      <div className="wl-container">
        <div className="wl-section-head">
          <div className="wl-pill mb-2">
            <BookOpen className="w-4 h-4 text-indigo-600" />
            <span>PLAYER MANUAL</span>
          </div>
          <h2>{t.guideTitle}</h2>
        </div>

        <article className="wl-reading">
          <h2>{t.guideSection1Title}</h2>
          <p className="whitespace-pre-line">{t.guideSection1Text}</p>

          <h2>{t.guideSection2Title}</h2>
          <p className="whitespace-pre-line">{t.guideSection2Text}</p>

          <h2>{t.guideSection3Title}</h2>
          <p className="whitespace-pre-line">{t.guideSection3Text}</p>

          <h2>{t.guideSection4Title}</h2>
          <p className="whitespace-pre-line">{t.guideSection4Text}</p>
        </article>
      </div>
    </section>
  );
};
