/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Language, PeriodType, PredictionData } from './types';
import {
  PERIOD_SECONDS,
  formatCountdown,
  generatePeriodData,
  getSecondsLeft,
} from './engine/wingoEngine';
import { fetchLiveWingoData } from './services/apiService';
import { Header } from './components/Header';
import { MobileDrawer } from './components/MobileDrawer';
import { HeroPrediction } from './components/HeroPrediction';
import { PeriodTabs } from './components/PeriodTabs';
import { LiveResultsSection } from './components/LiveResultsSection';
import { AnalysisTools } from './components/AnalysisTools';
import { ReadingGuide } from './components/ReadingGuide';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';
import { BottomSponsoredAd } from './components/BottomSponsoredAd';
import { PredictionLogModal } from './components/PredictionLogModal';
import { playTickBeep } from './utils/sound';

export default function App() {
  // Check if URL contains /hi
  const [language, setLanguage] = useState<Language>('en');

  const [currentPeriod, setCurrentPeriod] = useState<PeriodType>('1m');
  const [soundEnabled, setSoundEnabled] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isPredictionLogOpen, setIsPredictionLogOpen] = useState(false);

  const toggleLanguage = useCallback(() => {
    const nextLanguage: Language = language === 'en' ? 'hi' : 'en';
    setLanguage(nextLanguage);
  }, [language]);

  useEffect(() => {
    document.documentElement.lang = language;
  }, [language]);

  // Prediction data store for each period
  const [dataStore, setDataStore] = useState<Record<PeriodType, PredictionData>>(() => {
    const periods: PeriodType[] = ['30s', '1m'];
    const initial: Partial<Record<PeriodType, PredictionData>> = {};
    periods.forEach((p) => {
      initial[p] = generatePeriodData(p);
    });
    return initial as Record<PeriodType, PredictionData>;
  });

  // Countdown seconds for each period
  const [countdownMap, setCountdownMap] = useState<Record<PeriodType, number>>(() => ({
    '30s': getSecondsLeft(PERIOD_SECONDS['30s']),
    '1m': getSecondsLeft(PERIOD_SECONDS['1m']),
  }));

  const soundRef = useRef(soundEnabled);
  soundRef.current = soundEnabled;

  const currentPeriodRef = useRef(currentPeriod);
  currentPeriodRef.current = currentPeriod;

  // Load period data from real API
  const loadPeriodData = useCallback(async (period: PeriodType) => {
    try {
      const liveData = await fetchLiveWingoData(period);
      setDataStore((prev) => ({
        ...prev,
        [period]: liveData,
      }));
    } catch {
      // Graceful fallback to generator if network is offline
      setDataStore((prev) => ({
        ...prev,
        [period]: prev[period] || generatePeriodData(period),
      }));
    }
  }, []);

  // Fetch initial API data on mount for 30s and 1m
  useEffect(() => {
    loadPeriodData('30s');
    loadPeriodData('1m');
  }, [loadPeriodData]);

  // Refresh active period prediction
  const refreshActivePeriod = useCallback(async () => {
    setIsRefreshing(true);
    try {
      await loadPeriodData(currentPeriodRef.current);
    } finally {
      setTimeout(() => setIsRefreshing(false), 450);
    }
  }, [loadPeriodData]);

  // Main countdown timer loop
  useEffect(() => {
    const periods: PeriodType[] = ['30s', '1m'];

    const intervalId = setInterval(() => {
      const nextCountdowns: Record<PeriodType, number> = {
        '30s': 0,
        '1m': 0,
      };

      let activeEnded = false;

      periods.forEach((p) => {
        const left = getSecondsLeft(PERIOD_SECONDS[p]);
        nextCountdowns[p] = left;

        // Sound cue for active period under 5s
        if (p === currentPeriodRef.current && soundRef.current) {
          if (left <= 5 && left >= 1) {
            playTickBeep(false);
          } else if (left === 0) {
            playTickBeep(true);
          }
        }

        // When a period completes (left reaches 0 or resets to total-1)
        if (left <= 1) {
          if (p === currentPeriodRef.current) {
            activeEnded = true;
          }
        }
      });

      setCountdownMap(nextCountdowns);

      // Re-fetch live API data when the draw concludes
      if (activeEnded) {
        setTimeout(() => {
          loadPeriodData(currentPeriodRef.current);
        }, 1500);
      }
    }, 1000);

    return () => clearInterval(intervalId);
  }, [loadPeriodData]);

  // Format countdown map for tabs
  const formattedCountdownMap: Record<PeriodType, string> = {
    '30s': formatCountdown(countdownMap['30s']),
    '1m': formatCountdown(countdownMap['1m']),
  };

  const currentData = dataStore[currentPeriod] || generatePeriodData(currentPeriod);

  return (
    <div className="min-h-screen flex flex-col selection:bg-indigo-500 selection:text-white" lang={language}>
      {/* Skip to Content for Accessibility */}
      <a href="#live-prediction" className="wl-skip-link">
        Skip to main content
      </a>

      {/* Header */}
      <Header
        language={language}
        onToggleLanguage={toggleLanguage}
        soundEnabled={soundEnabled}
        onToggleSound={() => setSoundEnabled((prev) => !prev)}
        onOpenDrawer={() => setIsDrawerOpen(true)}
      />

      {/* Mobile Drawer (3-Dot Options & Prediction Controls) */}
      <MobileDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        language={language}
        onToggleLanguage={toggleLanguage}
        currentPeriod={currentPeriod}
        onSelectPeriod={(p) => {
          setCurrentPeriod(p);
          loadPeriodData(p);
        }}
        onOpenPredictionLog={() => setIsPredictionLogOpen(true)}
        countdownMap={formattedCountdownMap}
      />

      {/* Main Content Area */}
      <main className="wl-site-content grow">
        {/* Hero with Live Prediction Card */}
        <HeroPrediction
          data={currentData}
          countdown={countdownMap[currentPeriod]}
          language={language}
          onRefresh={refreshActivePeriod}
          isRefreshing={isRefreshing}
          onSelectPeriod={(p) => {
            setCurrentPeriod(p);
            loadPeriodData(p);
          }}
          onOpenPredictionLog={() => setIsPredictionLogOpen(true)}
          soundEnabled={soundEnabled}
          onToggleSound={() => setSoundEnabled((prev) => !prev)}
          countdownMap={formattedCountdownMap}
        />

        {/* Period Selector Tabs Bar & 3-Dot Options */}
        <section className="py-6 border-y border-slate-200/80 bg-white/70 backdrop-blur-xs">
          <div className="wl-container">
            <PeriodTabs
              currentPeriod={currentPeriod}
              onSelectPeriod={(p) => {
                setCurrentPeriod(p);
                loadPeriodData(p);
              }}
              language={language}
              countdownMap={formattedCountdownMap}
              onOpenPredictionLog={() => setIsPredictionLogOpen(true)}
              onRefresh={refreshActivePeriod}
              isRefreshing={isRefreshing}
              soundEnabled={soundEnabled}
              onToggleSound={() => setSoundEnabled((prev) => !prev)}
            />
          </div>
        </section>

        {/* Live Results Table & Today Live Reference Grid */}
        <LiveResultsSection data={currentData} language={language} />

        {/* Analysis & Martingale Tools */}
        <AnalysisTools language={language} />

        {/* Player Strategy & Rules Reading Section */}
        <ReadingGuide language={language} />

        {/* Frequently Asked Questions */}
        <FaqSection language={language} />
      </main>

      {/* Footer */}
      <Footer language={language} />

      {/* Bottom Sponsored Advertisement Bar (WINGO x 00097) */}
      <BottomSponsoredAd language={language} />

      {/* Recent Predictions Win/Loss Market Log Modal */}
      <PredictionLogModal
        isOpen={isPredictionLogOpen}
        onClose={() => setIsPredictionLogOpen(false)}
        data={currentData}
        period={currentPeriod}
        language={language}
      />
    </div>
  );
}
