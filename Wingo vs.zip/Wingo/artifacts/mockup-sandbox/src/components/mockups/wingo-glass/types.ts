export type PeriodType = '30s' | '1m';

export type SizePrediction = 'Big' | 'Small';

export type ColorType = 'Green' | 'Red' | 'Violet';

export type ConfidenceLevel = 'High' | 'Medium' | 'Low';

export interface HistoryRow {
  issue: string;
  number: number;
  size: SizePrediction;
  colors: ColorType[];
  time: string;
  won?: boolean;
}

export interface PredictionData {
  period: PeriodType;
  periodLabel: string;
  seconds: number;
  targetIssue: string;
  signal: SizePrediction;
  colors: ColorType[];
  number: number;
  confidence: ConfidenceLevel;
  accuracy: string;
  history: HistoryRow[];
}

export interface PredictionLogEntry {
  issue: string;
  time: string;
  predictedSize: SizePrediction;
  predictedColors: ColorType[];
  predictedNumber: number;
  actualNumber: number;
  actualSize: SizePrediction;
  actualColors: ColorType[];
  status: 'WIN' | 'LOSS';
  profitUnits: string;
}

export type Language = 'en' | 'hi';
