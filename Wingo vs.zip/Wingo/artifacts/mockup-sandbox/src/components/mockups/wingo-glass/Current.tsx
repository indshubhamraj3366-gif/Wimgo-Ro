import React from 'react';
import App from './App';
import './_group.css';

export default function Current() {
  return (
    <div className="wingo-preview">
      <App />
    </div>
  );
}
