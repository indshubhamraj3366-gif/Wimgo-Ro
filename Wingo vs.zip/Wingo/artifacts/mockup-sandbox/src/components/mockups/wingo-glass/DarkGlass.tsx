import React from 'react';
import App from './App';
import './_group.css';
import './DarkGlass.css';

export default function DarkGlass() {
  return (
    <div className="wingo-dark-glass">
      <App />
    </div>
  );
}
