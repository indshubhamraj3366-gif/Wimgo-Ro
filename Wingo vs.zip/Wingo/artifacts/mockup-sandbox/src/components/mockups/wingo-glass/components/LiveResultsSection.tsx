import React, { useState } from 'react';
import {
  History,
  Filter,
  BarChart3,
  TrendingUp,
  Flame,
  Snowflake,
  ShieldAlert,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import { ColorType, HistoryRow, Language, PredictionData } from '../types';
import { translations } from '../translations';

interface LiveResultsSectionProps {
  data: PredictionData;
  language: Language;
}

export const LiveResultsSection: React.FC<LiveResultsSectionProps> = ({
  data,
  language,
}) => {
  const t = translations[language];

  const getBallClass = (num: number) => {
    if (num === 0) return 'wl-number-ball wl-number-red-violet';
    if (num === 5) return 'wl-number-ball wl-number-green-violet';
    if ([1, 3, 7, 9].includes(num)) return 'wl-number-ball wl-number-green';
    return 'wl-number-ball wl-number-red';
  };

  const getColorClass = (color: ColorType) => {
    if (color === 'Green') return 'wl-tag wl-tag-green';
    if (color === 'Red') return 'wl-tag wl-tag-red';
    return 'wl-tag wl-tag-violet';
  };

  const translateColor = (color: ColorType) => {
    if (color === 'Green') return t.green;
    if (color === 'Red') return t.red;
    return t.violet;
  };

  // Calculate stats over current history
  const totalRounds = data.history.length || 1;
  const bigCount = data.history.filter((h) => h.size === 'Big').length;
  const smallCount = totalRounds - bigCount;
  const bigPercent = Math.round((bigCount / totalRounds) * 100);
  const smallPercent = 100 - bigPercent;

  const greenCount = data.history.filter((h) => h.colors.includes('Green')).length;
  const redCount = data.history.filter((h) => h.colors.includes('Red')).length;
  const violetCount = data.history.filter((h) => h.colors.includes('Violet')).length;

  // Streak detection on first few
  let currentStreakCount = 1;
  const currentStreakSize = data.history[0]?.size || 'Big';
  for (let i = 1; i < data.history.length; i++) {
    if (data.history[i].size === currentStreakSize) {
      currentStreakCount++;
    } else {
      break;
    }
  }

  // Hot/cold frequencies
  const frequencyMap: Record<number, number> = {};
  for (let i = 0; i < 10; i++) frequencyMap[i] = 0;
  data.history.forEach((h) => {
    frequencyMap[h.number] = (frequencyMap[h.number] || 0) + 1;
  });

  const sortedNumbers = Object.entries(frequencyMap)
    .sort((a, b) => b[1] - a[1])
    .map(([num]) => Number(num));

  const hotNumbers = sortedNumbers.slice(0, 3);
  const coldNumbers = sortedNumbers.slice(-3).reverse();

  return (
    <section id="draw-history" className="wl-section wl-soft-band">
      <div className="wl-container">
        <div className="wl-section-head">
          <div className="wl-pill mb-2">
            <History className="w-4 h-4 text-indigo-600" />
            <span>{t.badge}</span>
          </div>
          <h2>{t.historyTitle}</h2>
          <p>{t.historySubtitle}</p>
        </div>

        <div className="wl-two-col">
          {/* Left Column: Results List */}
          <div className="wl-results-card">
            <div className="wl-results-head">
              <div>
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
                  {data.periodLabel}
                </span>
                <h3>{t.historyTitle}</h3>
              </div>

              <div className="wl-score">
                <span>{data.accuracy}</span>
                <span className="text-xs font-medium text-indigo-600">Accuracy</span>
              </div>
            </div>

            {/* Rows */}
            <div className="wl-history-list">
              {data.history.map((row) => (
                <div key={row.issue} className="wl-history-row">
                  <div className="flex flex-col min-w-0">
                    <span className="wl-history-issue">#{row.issue}</span>
                    <span className="text-[11px] font-mono text-slate-400 font-medium">
                      IST {row.time}
                    </span>
                  </div>

                  <span className={getBallClass(row.number)} title={`Number ${row.number}`}>
                    {row.number}
                  </span>

                  <span
                    className={`wl-tag ${
                      row.size === 'Big' ? 'wl-tag-violet' : 'wl-tag-red'
                    }`}
                  >
                    {row.size === 'Big' ? t.big : t.small}
                  </span>

                  <div className="wl-history-colors">
                    {row.colors.map((c) => (
                      <span key={c} className={getColorClass(c)}>
                        {translateColor(c)}
                      </span>
                    ))}
                  </div>

                  <div className="hidden sm:flex items-center">
                    <span
                      className={`text-xs font-black px-2 py-0.5 rounded-md ${
                        row.won
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {row.won ? t.hitWon : t.hitMiss}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column: Today Live Reference Info Panel */}
          <div className="wl-info-panel">
            <div className="flex items-center justify-between">
              <div className="wl-icon-box">
                <BarChart3 className="w-6 h-6" />
              </div>
              <span className="text-xs font-black text-indigo-700 bg-indigo-50 border border-indigo-200 px-2.5 py-1 rounded-full">
                {t.badge}
              </span>
            </div>

            <h3>{t.referenceTitle}</h3>
            <p>{t.referenceDesc}</p>

            {/* Big vs Small Ratio Bar */}
            <div className="mt-5 p-4 rounded-xl bg-white border border-slate-200">
              <div className="flex justify-between text-xs font-black mb-1.5 text-slate-700">
                <span>{t.big}: {bigPercent}% ({bigCount})</span>
                <span>{t.small}: {smallPercent}% ({smallCount})</span>
              </div>
              <div className="w-full h-3 rounded-full bg-slate-100 overflow-hidden flex">
                <div
                  className="bg-gradient-to-r from-indigo-500 to-purple-600 h-full transition-all"
                  style={{ width: `${bigPercent}%` }}
                />
                <div
                  className="bg-gradient-to-r from-amber-400 to-rose-500 h-full transition-all"
                  style={{ width: `${smallPercent}%` }}
                />
              </div>
            </div>

            {/* Color Distribution Badges */}
            <div className="grid grid-cols-3 gap-2 mt-3">
              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-center">
                <span className="text-[11px] font-bold text-emerald-700 uppercase block">
                  {t.green}
                </span>
                <strong className="text-lg font-black text-emerald-900 block mt-0.5">
                  {greenCount}
                </strong>
              </div>

              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-center">
                <span className="text-[11px] font-bold text-rose-700 uppercase block">
                  {t.red}
                </span>
                <strong className="text-lg font-black text-rose-900 block mt-0.5">
                  {redCount}
                </strong>
              </div>

              <div className="p-3 rounded-xl bg-purple-50 border border-purple-200 text-center">
                <span className="text-[11px] font-bold text-purple-700 uppercase block">
                  {t.violet}
                </span>
                <strong className="text-lg font-black text-purple-900 block mt-0.5">
                  {violetCount}
                </strong>
              </div>
            </div>

            {/* Hot and Cold Numbers */}
            <div className="mt-4 p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold text-slate-700 flex items-center gap-1.5">
                  <Flame className="w-4 h-4 text-rose-500" />
                  {t.statHotNumbers}:
                </span>
                <div className="flex gap-1.5">
                  {hotNumbers.map((n) => (
                    <span
                      key={n}
                      className="w-6 h-6 rounded-full bg-rose-600 text-white font-black text-xs flex items-center justify-center shadow-xs"
                    >
                      {n}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                <span className="text-xs font-extrabold text-slate-700 flex items-center gap-1.5">
                  <Snowflake className="w-4 h-4 text-blue-500" />
                  {t.statColdNumbers}:
                </span>
                <div className="flex gap-1.5">
                  {coldNumbers.map((n) => (
                    <span
                      key={n}
                      className="w-6 h-6 rounded-full bg-blue-600 text-white font-black text-xs flex items-center justify-center shadow-xs"
                    >
                      {n}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Pattern Recognized Badge */}
            <div className="mt-4 p-3.5 rounded-xl bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-200 flex items-center gap-2.5">
              <Sparkles className="w-5 h-5 text-indigo-600 shrink-0" />
              <div>
                <span className="text-[11px] font-extrabold text-indigo-600 uppercase tracking-wide block">
                  {t.patternIdentified}
                </span>
                <strong className="text-xs font-black text-slate-900">
                  {currentStreakCount >= 3
                    ? `${currentStreakSize === 'Big' ? t.big : t.small} Dragon Streak (${currentStreakCount}x)`
                    : 'Alternating Balanced Trend (ABAB)'}
                </strong>
              </div>
            </div>

            {/* Rules checklist */}
            <ul className="wl-check-list">
              <li>Strict 10-period rolling mathematical verification</li>
              <li>Dual-color 0 and 5 frequency balancing</li>
              <li>Synchronized with official Indian Standard Time clocks</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};
