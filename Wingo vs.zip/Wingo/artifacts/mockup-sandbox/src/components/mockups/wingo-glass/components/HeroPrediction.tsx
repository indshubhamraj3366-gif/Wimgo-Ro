import React, { useState } from 'react';
import {
  RotateCw,
  Copy,
  Check,
  Zap,
  TrendingUp,
  ShieldCheck,
  Users,
  Flame,
  Clock,
  Sparkles,
} from 'lucide-react';
import { Language, PeriodType, PredictionData } from '../types';
import { translations } from '../translations';
import { formatCountdown } from '../engine/wingoEngine';
import { ThreeDotMenu } from './ThreeDotMenu';

interface HeroPredictionProps {
  data: PredictionData;
  countdown: number;
  language: Language;
  onRefresh: () => void;
  isRefreshing: boolean;
  onSelectPeriod: (p: PeriodType) => void;
  onOpenPredictionLog: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  countdownMap: Record<PeriodType, string>;
}

export const HeroPrediction: React.FC<HeroPredictionProps> = ({
  data,
  countdown,
  language,
  onRefresh,
  isRefreshing,
  onSelectPeriod,
  onOpenPredictionLog,
  soundEnabled,
  onToggleSound,
  countdownMap,
}) => {
  const t = translations[language];
  const [copied, setCopied] = useState(false);

  const handleCopyIssue = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(data.targetIssue);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const isUrgent = countdown <= 10;

  const translateColor = (color: string) => {
    if (color === 'Green') return t.green;
    if (color === 'Red') return t.red;
    if (color === 'Violet') return t.violet;
    return color;
  };

  const translateConfidence = (level: string) => {
    if (level === 'High') return t.high;
    if (level === 'Medium') return t.medium;
    if (level === 'Low') return t.low;
    return level;
  };

  return (
    <section id="live-prediction" className="wl-hero">
      <div className="wl-container">
        <div className="wl-hero-grid">
          {/* Left Column: Hero Copy */}
          <div className="wl-hero-copy">
            <div className="wl-pill">
              <Sparkles className="w-4 h-4 text-indigo-600 animate-spin" />
              <span>{t.heroEyebrow}</span>
            </div>

            <h1>
              {t.heroTitlePrefix}{' '}
              <span className="wl-gradient-text">{t.heroTitleGradient}</span>{' '}
              {t.heroTitleSuffix}
            </h1>

            <p className="wl-lead">{t.heroSubtitle}</p>

            <div className="wl-hero-actions">
              <a href="#draw-history" className="wl-btn wl-btn-primary">
                <TrendingUp className="w-4 h-4" />
                <span>{t.navHistory}</span>
              </a>

              <a href="#analysis-tools" className="wl-btn wl-btn-soft">
                <Zap className="w-4 h-4" />
                <span>{t.navTools}</span>
              </a>
            </div>

            <div className="wl-trust-row">
              <span>
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                {t.accuracyBadge}
              </span>
              <span>
                <Users className="w-4 h-4 text-emerald-500" />
                {t.activeUsersBadge}
              </span>
              <span>
                <Clock className="w-4 h-4 text-emerald-500" />
                {t.istSyncedBadge}
              </span>
            </div>
          </div>

          {/* Right Column: Live Card (From Uploaded Design) */}
          <div className="wl-hero-visual">
            <div className="wl-live-card">
              {/* Card Top */}
              <div className="wl-live-top">
                <div>
                  <span className="wl-live-label">
                    <span className="relative flex h-2.5 w-2.5 mr-1">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                    </span>
                    {t.liveCardTitle}
                  </span>
                  <h3>{data.periodLabel}</h3>
                </div>

                <div className="flex items-center gap-2">
                  <div className="wl-live-badge">
                    <span className="pulse-dot"></span>
                    <span>{t.badge}</span>
                  </div>

                  <ThreeDotMenu
                    currentPeriod={data.period}
                    onSelectPeriod={onSelectPeriod}
                    onOpenPredictionLog={onOpenPredictionLog}
                    onRefresh={onRefresh}
                    isRefreshing={isRefreshing}
                    soundEnabled={soundEnabled}
                    onToggleSound={onToggleSound}
                    language={language}
                    countdownMap={countdownMap}
                  />
                </div>
              </div>

              {/* Active Period & Issue */}
              <div className="wl-draw-box">
                <div>
                  <span>{t.drawIssue}</span>
                  <div className="flex items-center gap-2 mt-1">
                    <strong className="tracking-wide font-mono text-indigo-950">
                      #{data.targetIssue}
                    </strong>
                    <button
                      type="button"
                      onClick={handleCopyIssue}
                      className="p-1.5 rounded-md hover:bg-indigo-100 text-indigo-600 transition-colors"
                      title="Copy Issue Number"
                    >
                      {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <span>{t.timeRemaining}</span>
                  <div className={`wl-countdown ${isUrgent ? 'is-urgent' : ''}`}>
                    {formatCountdown(countdown)}
                  </div>
                </div>
              </div>

              {/* 3-Box Signal Grid */}
              <div className="wl-signal-grid">
                <div>
                  <span>{t.signal}</span>
                  <strong className={data.signal === 'Big' ? 'text-indigo-600' : 'text-amber-600'}>
                    {data.signal === 'Big' ? t.big : t.small}
                  </strong>
                </div>

                <div>
                  <span>{t.targetColor}</span>
                  <div className="flex flex-wrap gap-1 mt-1.5">
                    {data.colors.map((c) => (
                      <span
                        key={c}
                        className={`wl-tag text-xs font-black ${
                          c === 'Green'
                            ? 'wl-tag-green'
                            : c === 'Red'
                            ? 'wl-tag-red'
                            : 'wl-tag-violet'
                        }`}
                      >
                        {translateColor(c)}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <span>{t.recommendedNumber}</span>
                  <strong className="text-rose-600 text-xl font-black">
                    {data.number}
                  </strong>
                </div>
              </div>

              {/* Card Bottom Meta */}
              <div className="wl-live-bottom">
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 font-bold">{t.confidence}:</span>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-indigo-50 text-indigo-700 border border-indigo-200">
                    {translateConfidence(data.confidence)}
                  </span>
                  <span className="text-slate-400">·</span>
                  <span className="text-slate-500 font-bold text-xs">{data.accuracy} hit</span>
                </div>

                <button
                  type="button"
                  onClick={onRefresh}
                  disabled={isRefreshing}
                  className="wl-mini-btn"
                >
                  <RotateCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
                  <span>{isRefreshing ? t.refreshing : t.refreshSignal}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
