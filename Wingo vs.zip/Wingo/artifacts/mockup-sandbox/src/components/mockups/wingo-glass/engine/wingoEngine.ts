import { ColorType, ConfidenceLevel, HistoryRow, PeriodType, PredictionData, SizePrediction } from '../types';

export const PERIOD_SECONDS: Record<PeriodType, number> = {
  '30s': 30,
  '1m': 60,
};

export const PERIOD_NAMES: Record<PeriodType, string> = {
  '30s': 'WinGo 30s',
  '1m': 'WinGo 1 Min',
};

// Calculate exact IST seconds left
export function getSecondsLeft(totalSeconds: number): number {
  totalSeconds = Number(totalSeconds || 60);
  const now = new Date();
  const utc = now.getTime() + now.getTimezoneOffset() * 60000;
  const india = new Date(utc + 330 * 60000); // UTC+5:30
  const secondsToday =
    india.getHours() * 3600 +
    india.getMinutes() * 60 +
    india.getSeconds();

  const left = totalSeconds - (secondsToday % totalSeconds);
  return left === totalSeconds ? 0 : left;
}

export function formatCountdown(seconds: number): string {
  const safe = Math.max(0, Math.floor(seconds || 0));
  const minutes = Math.floor(safe / 60);
  const remain = safe % 60;
  return String(minutes).padStart(2, '0') + ':' + String(remain).padStart(2, '0');
}

export function getIndiaDateInfo() {
  const now = new Date();
  const utc = now.getTime() + now.getTimezoneOffset() * 60000;
  const india = new Date(utc + 330 * 60000);

  const year = india.getFullYear();
  const month = String(india.getMonth() + 1).padStart(2, '0');
  const day = String(india.getDate()).padStart(2, '0');
  const dateStr = `${year}${month}${day}`;

  const secondsToday =
    india.getHours() * 3600 +
    india.getMinutes() * 60 +
    india.getSeconds();

  return { india, dateStr, secondsToday };
}

export function getNumberDetails(num: number): { size: SizePrediction; colors: ColorType[] } {
  const n = Math.max(0, Math.min(9, Math.floor(num)));
  const size: SizePrediction = n >= 5 ? 'Big' : 'Small';

  if (n === 0) {
    return { size: 'Small', colors: ['Red', 'Violet'] };
  }
  if (n === 5) {
    return { size: 'Big', colors: ['Green', 'Violet'] };
  }
  if ([1, 3, 7, 9].includes(n)) {
    return { size, colors: ['Green'] };
  }
  return { size, colors: ['Red'] };
}

// Pseudo-random deterministic generator based on issue string
function pseudoRandom(seedStr: string): number {
  let hash = 0;
  for (let i = 0; i < seedStr.length; i++) {
    const char = seedStr.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  const x = Math.sin(hash) * 10000;
  return x - Math.floor(x);
}

export function generateHistoricalDraws(period: PeriodType, count: number = 25): HistoryRow[] {
  const { dateStr, secondsToday } = getIndiaDateInfo();
  const interval = PERIOD_SECONDS[period];
  const currentRoundIndex = Math.max(1, Math.floor(secondsToday / interval));

  const rows: HistoryRow[] = [];

  for (let i = 1; i <= count; i++) {
    const roundNumber = currentRoundIndex - i + 1;
    if (roundNumber <= 0) continue;

    // Issue ID: Date + 10000 + round
    const paddedRound = String(roundNumber).padStart(4, '0');
    const issue = `${dateStr}100${paddedRound}`;

    const rnd = pseudoRandom(`${issue}-${period}`);
    const num = Math.floor(rnd * 10);
    const { size, colors } = getNumberDetails(num);

    // Simulated time
    const roundSeconds = roundNumber * interval;
    const hrs = String(Math.floor(roundSeconds / 3600) % 24).padStart(2, '0');
    const mins = String(Math.floor((roundSeconds % 3600) / 60)).padStart(2, '0');
    const secs = String(roundSeconds % 60).padStart(2, '0');
    const time = `${hrs}:${mins}:${secs}`;

    // Prediction won check
    const wonRnd = pseudoRandom(`pred-${issue}`);
    const won = wonRnd > 0.12; // ~88% hit rate

    rows.push({
      issue,
      number: num,
      size,
      colors,
      time,
      won,
    });
  }

  return rows;
}

export function generatePeriodData(period: PeriodType): PredictionData {
  const interval = PERIOD_SECONDS[period];
  const { dateStr, secondsToday } = getIndiaDateInfo();
  const currentRoundIndex = Math.max(1, Math.floor(secondsToday / interval));

  // The next issue being predicted
  const nextRoundNumber = currentRoundIndex + 1;
  const targetIssue = `${dateStr}100${String(nextRoundNumber).padStart(4, '0')}`;

  const history = generateHistoricalDraws(period, 25);

  // Analyze history for trend signal
  const recentSizes = history.slice(0, 5).map((r) => r.size);
  const bigCount = recentSizes.filter((s) => s === 'Big').length;

  let signal: SizePrediction;
  let confidence: ConfidenceLevel = 'High';
  let colors: ColorType[];
  let recommendedNum: number;

  const rnd = pseudoRandom(`signal-${targetIssue}-${period}`);

  // Trend detection:
  // If recent streak has 4 Bigs, either dragon continues or jumps
  if (bigCount >= 4) {
    signal = rnd > 0.4 ? 'Small' : 'Big';
    confidence = 'High';
  } else if (bigCount <= 1) {
    signal = rnd > 0.4 ? 'Big' : 'Small';
    confidence = 'High';
  } else {
    signal = rnd > 0.5 ? 'Big' : 'Small';
    confidence = rnd > 0.25 ? 'High' : 'Medium';
  }

  // Recommended colors and key number
  if (signal === 'Big') {
    if (rnd > 0.5) {
      colors = ['Green'];
      recommendedNum = rnd > 0.75 ? 7 : 9;
    } else if (rnd > 0.15) {
      colors = ['Red'];
      recommendedNum = rnd > 0.35 ? 6 : 8;
    } else {
      colors = ['Green', 'Violet'];
      recommendedNum = 5;
    }
  } else {
    if (rnd > 0.5) {
      colors = ['Red'];
      recommendedNum = rnd > 0.75 ? 2 : 4;
    } else if (rnd > 0.15) {
      colors = ['Green'];
      recommendedNum = rnd > 0.35 ? 1 : 3;
    } else {
      colors = ['Red', 'Violet'];
      recommendedNum = 0;
    }
  }

  // Accuracy calculation based on recent win records
  const wonCount = history.slice(0, 20).filter((h) => h.won).length;
  const rawAcc = (wonCount / 20) * 100;
  const accuracy = `${(rawAcc > 85 ? rawAcc : 92.4).toFixed(1)}%`;

  return {
    period,
    periodLabel: PERIOD_NAMES[period],
    seconds: getSecondsLeft(interval),
    targetIssue,
    signal,
    colors,
    number: recommendedNum,
    confidence,
    accuracy,
    history,
  };
}
