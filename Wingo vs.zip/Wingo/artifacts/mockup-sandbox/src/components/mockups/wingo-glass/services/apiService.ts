import { PeriodType, PredictionData } from '../types';
import { generatePeriodData } from '../engine/wingoEngine';

/**
 * Local preview data only. The production app continues to use its live API.
 */
export async function fetchLiveWingoData(period: PeriodType): Promise<PredictionData> {
  await new Promise((resolve) => window.setTimeout(resolve, 120));
  return generatePeriodData(period);
}
