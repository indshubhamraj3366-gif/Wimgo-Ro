import React, { useState, useRef, useEffect } from 'react';
import {
  MoreVertical,
  Clock,
  BarChart3,
  RotateCw,
  Volume2,
  VolumeX,
  Send,
  Sparkles,
  Check,
} from 'lucide-react';
import { Language, PeriodType } from '../types';
import { translations } from '../translations';

interface ThreeDotMenuProps {
  currentPeriod: PeriodType;
  onSelectPeriod: (p: PeriodType) => void;
  onOpenPredictionLog: () => void;
  onRefresh: () => void;
  isRefreshing: boolean;
  soundEnabled: boolean;
  onToggleSound: () => void;
  language: Language;
  countdownMap: Record<PeriodType, string>;
}

export const ThreeDotMenu: React.FC<ThreeDotMenuProps> = ({
  currentPeriod,
  onSelectPeriod,
  onOpenPredictionLog,
  onRefresh,
  isRefreshing,
  soundEnabled,
  onToggleSound,
  language,
  countdownMap,
}) => {
  const t = translations[language];
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close on outside click
  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleOutsideClick);
    }
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
    };
  }, [isOpen]);

  const periods: PeriodType[] = ['30s', '1m'];

  return (
    <div className="relative inline-block text-left" ref={menuRef}>
      {/* 3-Dot Trigger Button */}
      <button
        type="button"
        onClick={() => setIsOpen((prev) => !prev)}
        className="inline-flex items-center justify-center w-10 h-10 rounded-2xl bg-white border border-slate-200/90 shadow-md shadow-indigo-500/5 hover:border-indigo-300 hover:bg-indigo-50/50 text-slate-700 hover:text-indigo-600 transition-all focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20"
        aria-expanded={isOpen}
        aria-haspopup="true"
        title={t.threeDotOptions}
      >
        <MoreVertical className="w-5 h-5" />
      </button>

      {/* Floating Dropdown */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-72 sm:w-80 rounded-3xl bg-white shadow-2xl border border-indigo-100 p-3 z-50 animate-in fade-in zoom-in-95 duration-150 origin-top-right">
          {/* Header */}
          <div className="flex items-center justify-between px-3 py-2 border-b border-slate-100 mb-2">
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-400">
              {t.threeDotOptions}
            </span>
            <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
              LIVE IST
            </span>
          </div>

          {/* Section 1: Period Selection */}
          <div className="mb-2">
            <div className="px-3 py-1 text-xs font-black text-slate-700 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-indigo-600" />
              <span>{t.switchPeriod}</span>
            </div>
            <div className="grid grid-cols-2 gap-1.5 mt-1.5 p-1 bg-slate-50 rounded-2xl">
              {periods.map((p) => {
                const isActive = currentPeriod === p;
                const info = t.periods[p];
                const time = countdownMap[p] || '00:00';

                return (
                  <button
                    key={p}
                    type="button"
                    onClick={() => {
                      onSelectPeriod(p);
                      setIsOpen(false);
                    }}
                    className={`flex flex-col p-2.5 rounded-xl text-left transition-all relative ${
                      isActive
                        ? 'bg-white shadow-md border border-indigo-200 text-indigo-600'
                        : 'text-slate-600 hover:bg-white/60'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black">{info.name}</span>
                      {isActive && <Check className="w-3.5 h-3.5 text-indigo-600" />}
                    </div>
                    <span className="text-[11px] font-mono font-bold text-slate-400 mt-0.5">
                      {time}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 2: NEW BUTTON: Log Recent Prediction (Win/Loss Market) */}
          <div className="pt-2 border-t border-slate-100 mb-2">
            <button
              type="button"
              onClick={() => {
                setIsOpen(false);
                onOpenPredictionLog();
              }}
              className="w-full flex items-center justify-between p-3 rounded-2xl bg-gradient-to-r from-indigo-500 via-purple-600 to-indigo-600 text-white font-extrabold text-xs shadow-md shadow-indigo-600/25 hover:opacity-95 hover:scale-[1.01] transition-all group"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-white/20 flex items-center justify-center">
                  <BarChart3 className="w-4 h-4 text-white" />
                </div>
                <div className="flex flex-col text-left">
                  <span className="font-black text-xs leading-tight">
                    {t.logRecentPredictionsShort}
                  </span>
                  <span className="text-[10px] text-indigo-100 font-medium">
                    Win & Loss Market Record
                  </span>
                </div>
              </div>

              <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-300 text-indigo-950 shadow-xs">
                AUDIT
              </span>
            </button>
          </div>

          {/* Section 3: Extra Actions */}
          <div className="flex flex-col gap-1 pt-1 border-t border-slate-100">
            {/* Refresh */}
            <button
              type="button"
              onClick={() => {
                onRefresh();
                setIsOpen(false);
              }}
              disabled={isRefreshing}
              className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-extrabold text-slate-700 hover:bg-indigo-50 hover:text-indigo-600 transition-colors"
            >
              <RotateCw className={`w-4 h-4 text-slate-400 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span>{isRefreshing ? t.refreshing : t.refreshSignal}</span>
            </button>

            {/* Sound Toggle */}
            <button
              type="button"
              onClick={() => {
                onToggleSound();
              }}
              className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-extrabold text-slate-700 hover:bg-indigo-50 hover:text-indigo-600 transition-colors"
            >
              {soundEnabled ? (
                <>
                  <Volume2 className="w-4 h-4 text-emerald-600" />
                  <span>{t.soundOn}</span>
                </>
              ) : (
                <>
                  <VolumeX className="w-4 h-4 text-slate-400" />
                  <span>{t.soundOff}</span>
                </>
              )}
            </button>

            {/* Telegram Link */}
            <a
              href="https://t.me/+lWlvfbR1BkI5YjFl"
              target="_blank"
              rel="noreferrer noopener"
              onClick={() => setIsOpen(false)}
              className="flex items-center justify-between px-3 py-2 rounded-xl text-xs font-extrabold text-indigo-600 hover:bg-indigo-50 transition-colors"
            >
              <div className="flex items-center gap-2.5">
                <Send className="w-4 h-4" />
                <span>{t.joinTelegram}</span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">↗</span>
            </a>
          </div>
        </div>
      )}
    </div>
  );
};
