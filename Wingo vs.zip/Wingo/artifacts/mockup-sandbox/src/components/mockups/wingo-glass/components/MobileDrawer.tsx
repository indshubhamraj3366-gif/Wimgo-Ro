import React from 'react';
import {
  X,
  Send,
  Globe,
  Flame,
  Radio,
  History,
  Wrench,
  BookOpen,
  HelpCircle,
  Clock,
  BarChart3,
  Check,
} from 'lucide-react';
import { Language, PeriodType } from '../types';
import { translations } from '../translations';

interface MobileDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onToggleLanguage: () => void;
  currentPeriod: PeriodType;
  onSelectPeriod: (p: PeriodType) => void;
  onOpenPredictionLog: () => void;
  countdownMap: Record<PeriodType, string>;
}

export const MobileDrawer: React.FC<MobileDrawerProps> = ({
  isOpen,
  onClose,
  language,
  onToggleLanguage,
  currentPeriod,
  onSelectPeriod,
  onOpenPredictionLog,
  countdownMap,
}) => {
  const t = translations[language];
  const periods: PeriodType[] = ['30s', '1m'];

  if (!isOpen) return null;

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 bg-slate-950/60 z-50 backdrop-blur-xs transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Drawer */}
      <div className="fixed inset-y-0 left-0 w-84 max-w-[88vw] bg-white z-50 shadow-2xl flex flex-col p-6 overflow-y-auto animate-in slide-in-from-left duration-250">
        {/* Head */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-md">
              <Flame className="w-5 h-5 fill-amber-300 text-amber-300" />
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-black text-slate-900 leading-none">
                WinGo<span className="text-indigo-600">Lottery</span>
              </span>
              <span className="text-[10px] font-bold text-slate-400 uppercase mt-0.5">
                {t.threeDotOptions}
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-lg flex items-center justify-center text-slate-500 hover:bg-slate-100 transition-colors"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Section 1: Period Selection */}
        <div className="pt-4 pb-2 border-b border-slate-100">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-black text-slate-800 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-indigo-600" />
              <span>{t.switchPeriod}</span>
            </span>
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-500">
              IST Sync
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {periods.map((p) => {
              const isActive = currentPeriod === p;
              const info = t.periods[p];
              const time = countdownMap[p] || '00:00';

              return (
                <button
                  key={p}
                  type="button"
                  onClick={() => {
                    onSelectPeriod(p);
                    onClose();
                  }}
                  className={`p-3 rounded-2xl text-left border transition-all ${
                    isActive
                      ? 'bg-indigo-50/70 border-indigo-300 shadow-xs'
                      : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-xs font-black ${
                        isActive ? 'text-indigo-700' : 'text-slate-800'
                      }`}
                    >
                      {info.name}
                    </span>
                    {isActive && <Check className="w-3.5 h-3.5 text-indigo-600" />}
                  </div>
                  <span className="text-[11px] font-mono font-bold text-slate-500 block mt-1">
                    {time}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Section 2: NEW BUTTON: Log Recent Predictions (Win/Loss Market) */}
        <div className="py-4 border-b border-slate-100">
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenPredictionLog();
            }}
            className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600 text-white font-black text-xs shadow-lg shadow-indigo-600/25 hover:opacity-95 transition-all group"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center">
                <BarChart3 className="w-4 h-4 text-white" />
              </div>
              <div className="flex flex-col text-left">
                <span className="font-black text-xs leading-tight">
                  {t.logRecentPredictions}
                </span>
                <span className="text-[10px] text-indigo-100 font-medium">
                  Audited Live Win/Loss Record
                </span>
              </div>
            </div>

            <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-300 text-slate-950 shadow-xs">
              LOG
            </span>
          </button>
        </div>

        {/* Navigation list */}
        <nav className="flex flex-col gap-1 py-4">
          <a
            href="#live-prediction"
            onClick={onClose}
            className="flex items-center gap-3 px-3 py-2 rounded-xl text-slate-800 font-bold hover:bg-indigo-50 hover:text-indigo-600 transition-colors"
          >
            <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Radio className="w-4 h-4" />
            </div>
            <span>{t.navSignals}</span>
          </a>

          <a
            href="#draw-history"
            onClick={onClose}
            className="flex items-center gap-3 px-3 py-2 rounded-xl text-slate-800 font-bold hover:bg-indigo-50 hover:text-indigo-600 transition-colors"
          >
            <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <History className="w-4 h-4" />
            </div>
            <span>{t.navHistory}</span>
          </a>

          <a
            href="#analysis-tools"
            onClick={onClose}
            className="flex items-center gap-3 px-3 py-2 rounded-xl text-slate-800 font-bold hover:bg-indigo-50 hover:text-indigo-600 transition-colors"
          >
            <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Wrench className="w-4 h-4" />
            </div>
            <span>{t.navTools}</span>
          </a>

          <a
            href="#rules-guide"
            onClick={onClose}
            className="flex items-center gap-3 px-3 py-2 rounded-xl text-slate-800 font-bold hover:bg-indigo-50 hover:text-indigo-600 transition-colors"
          >
            <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <BookOpen className="w-4 h-4" />
            </div>
            <span>{t.navGuide}</span>
          </a>

          <a
            href="#faq"
            onClick={onClose}
            className="flex items-center gap-3 px-3 py-2 rounded-xl text-slate-800 font-bold hover:bg-indigo-50 hover:text-indigo-600 transition-colors"
          >
            <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <HelpCircle className="w-4 h-4" />
            </div>
            <span>{t.navFaq}</span>
          </a>
        </nav>

        {/* Drawer Bottom Actions */}
        <div className="mt-auto flex flex-col gap-2.5 pt-4 border-t border-slate-100">
          <button
            type="button"
            onClick={() => {
              onToggleLanguage();
              onClose();
            }}
            className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl border border-indigo-200 bg-indigo-50/60 text-indigo-700 font-extrabold text-xs hover:bg-indigo-100 transition-colors"
          >
            <Globe className="w-4 h-4 text-indigo-600" />
            <span>Switch to {language === 'en' ? 'हिन्दी (Hindi)' : 'English'}</span>
          </button>

          <a
            href="https://t.me/+lWlvfbR1BkI5YjFl"
            target="_blank"
            rel="noreferrer noopener"
            className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-extrabold text-xs shadow-md shadow-indigo-600/20"
          >
            <Send className="w-4 h-4 fill-white" />
            <span>{t.joinTelegram}</span>
          </a>
        </div>
      </div>
    </>
  );
};
