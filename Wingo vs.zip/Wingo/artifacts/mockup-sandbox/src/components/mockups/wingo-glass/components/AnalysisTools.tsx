import React, { useState } from 'react';
import {
  Calculator,
  ScanEye,
  Grid3X3,
  Send,
  ArrowRight,
  TrendingUp,
  Shield,
  Coins,
} from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';

interface AnalysisToolsProps {
  language: Language;
}

export const AnalysisTools: React.FC<AnalysisToolsProps> = ({ language }) => {
  const t = translations[language];

  // Martingale Calculator state
  const [baseBet, setBaseBet] = useState<number>(10);
  const [multiplier, setMultiplier] = useState<number>(3);
  const [stages, setStages] = useState<number>(6);

  // Generate Martingale stages
  const calculateStages = () => {
    const list = [];
    let cumulative = 0;
    let currentBet = baseBet;

    for (let i = 1; i <= stages; i++) {
      cumulative += currentBet;
      // standard win payout 2x minus 2% fee ~ 1.96x
      const grossWin = currentBet * 1.96;
      const netProfit = grossWin - cumulative;
      list.push({
        stage: i,
        bet: currentBet,
        totalInvested: cumulative,
        netProfit: Math.round(netProfit * 10) / 10,
      });
      currentBet = Math.ceil(currentBet * multiplier);
    }
    return list;
  };

  const calculatedStages = calculateStages();

  return (
    <section id="analysis-tools" className="wl-section">
      <div className="wl-container">
        <div className="wl-section-head">
          <div className="wl-pill mb-2">
            <Calculator className="w-4 h-4 text-indigo-600" />
            <span>VIP PRO TOOLS</span>
          </div>
          <h2>{t.toolsSectionTitle}</h2>
          <p>{t.toolsSectionSubtitle}</p>
        </div>

        {/* 4 Feature Cards */}
        <div className="wl-card-grid wl-card-grid-4 mb-10">
          <div className="wl-tool-card">
            <div className="wl-icon-box">
              <Calculator className="w-6 h-6" />
            </div>
            <strong>{t.tool1Title}</strong>
            <span>{t.tool1Desc}</span>
          </div>

          <div className="wl-tool-card">
            <div className="wl-icon-box">
              <ScanEye className="w-6 h-6 text-purple-600" />
            </div>
            <strong>{t.tool2Title}</strong>
            <span>{t.tool2Desc}</span>
          </div>

          <div className="wl-tool-card">
            <div className="wl-icon-box">
              <Grid3X3 className="w-6 h-6 text-emerald-600" />
            </div>
            <strong>{t.tool3Title}</strong>
            <span>{t.tool3Desc}</span>
          </div>

          <a
            href="https://t.me/+lWlvfbR1BkI5YjFl"
            target="_blank"
            rel="noreferrer noopener"
            className="wl-tool-card group cursor-pointer hover:border-indigo-400"
          >
            <div className="wl-icon-box group-hover:scale-105 transition-transform">
              <Send className="w-6 h-6 text-blue-600" />
            </div>
            <strong className="flex items-center justify-between">
              {t.tool4Title}
              <span className="text-xs text-indigo-600 font-bold">Join ↗</span>
            </strong>
            <span>{t.tool4Desc}</span>
          </a>
        </div>

        {/* Interactive Martingale Calculator Widget */}
        <div className="p-6 sm:p-8 rounded-3xl bg-white border border-indigo-100 shadow-xl shadow-indigo-500/5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2">
                <Coins className="w-5 h-5 text-indigo-600" />
                <h3 className="text-xl font-black text-slate-900">{t.tool1Title}</h3>
              </div>
              <p className="text-sm text-slate-500 mt-1">
                Simulate capital allocation curves to maintain positive expected value during losing streaks.
              </p>
            </div>

            {/* Inputs */}
            <div className="flex flex-wrap items-center gap-3">
              <div>
                <label className="text-[11px] font-bold text-slate-500 uppercase block mb-1">
                  Base Bet (₹)
                </label>
                <input
                  type="number"
                  min="1"
                  max="50000"
                  value={baseBet}
                  onChange={(e) => setBaseBet(Math.max(1, Number(e.target.value) || 1))}
                  className="w-24 px-3 py-1.5 rounded-lg border border-slate-300 text-sm font-black focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-500 uppercase block mb-1">
                  Multiplier
                </label>
                <select
                  value={multiplier}
                  onChange={(e) => setMultiplier(Number(e.target.value))}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 text-sm font-black focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                >
                  <option value={2}>2.0x (Standard)</option>
                  <option value={2.5}>2.5x (Safe)</option>
                  <option value={3}>3.0x (Aggressive 3x)</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-500 uppercase block mb-1">
                  Safety Levels
                </label>
                <select
                  value={stages}
                  onChange={(e) => setStages(Number(e.target.value))}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 text-sm font-black focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                >
                  <option value={4}>4 Stages</option>
                  <option value={5}>5 Stages</option>
                  <option value={6}>6 Stages (Recommended)</option>
                  <option value={7}>7 Stages</option>
                </select>
              </div>
            </div>
          </div>

          {/* Calculator Table */}
          <div className="overflow-x-auto mt-6">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 text-xs font-black uppercase">
                  <th className="pb-3 pl-2">Stage</th>
                  <th className="pb-3">Round Bet</th>
                  <th className="pb-3">Cumulative Capital</th>
                  <th className="pb-3">Estimated Net Profit</th>
                  <th className="pb-3 pr-2">Safety Buffer</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {calculatedStages.map((stg) => (
                  <tr key={stg.stage} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 pl-2 font-black text-indigo-700">Level {stg.stage}</td>
                    <td className="py-3 font-mono font-bold text-slate-900">₹{stg.bet.toLocaleString()}</td>
                    <td className="py-3 font-mono font-bold text-slate-600">
                      ₹{stg.totalInvested.toLocaleString()}
                    </td>
                    <td className="py-3 font-mono font-black text-emerald-600">
                      +₹{stg.netProfit.toLocaleString()}
                    </td>
                    <td className="py-3 pr-2">
                      <span className="inline-flex items-center gap-1 text-xs font-extrabold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700">
                        Level {stg.stage} Shield
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
};
