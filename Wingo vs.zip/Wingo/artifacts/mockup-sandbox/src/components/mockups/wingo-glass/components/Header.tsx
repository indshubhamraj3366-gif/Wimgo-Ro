import React from 'react';
import { Volume2, VolumeX, MoreVertical, Globe, Send, Flame } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';

interface HeaderProps {
  language: Language;
  onToggleLanguage: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onOpenDrawer: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  language,
  onToggleLanguage,
  soundEnabled,
  onToggleSound,
  onOpenDrawer,
}) => {
  const t = translations[language];

  return (
    <header className="wl-site-header">
      <div className="wl-container">
        <div className="wl-header-inner">
          {/* 3-Dot Options Button (Selected by user) */}
          <button
            type="button"
            className="inline-flex items-center justify-center w-10 h-10 rounded-xl bg-purple-50 text-indigo-700 hover:bg-purple-100 hover:text-indigo-800 transition-all border border-indigo-200/60 shadow-xs cursor-pointer active:scale-95"
            onClick={onOpenDrawer}
            aria-label="3-Dot Options Menu"
            title="3-Dot Menu & Options"
          >
            <MoreVertical className="w-6 h-6" />
          </button>

          {/* Logo */}
          <a href="#" className="wl-logo flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-indigo-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
              <Flame className="w-6 h-6 fill-amber-300 text-amber-300 animate-pulse" />
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-black tracking-tight text-slate-900 leading-none">
                WinGo<span className="text-indigo-600">Lottery</span>
              </span>
              <span className="text-[10px] font-bold text-slate-500 tracking-wider uppercase mt-1">
                AI Signals & Analytics
              </span>
            </div>
          </a>

          {/* Desktop Navigation */}
          <nav className="wl-desktop-nav">
            <a href="#live-prediction" className="is-active">
              {t.navSignals}
            </a>
            <a href="#draw-history">{t.navHistory}</a>
            <a href="#analysis-tools">{t.navTools}</a>
            <a href="#rules-guide">{t.navGuide}</a>
            <a href="#faq">{t.navFaq}</a>
          </nav>

          {/* Header Actions */}
          <div className="wl-header-actions">
            {/* Sound Toggle */}
            <button
              type="button"
              onClick={onToggleSound}
              className={`p-2.5 rounded-xl border transition-all text-xs font-semibold flex items-center gap-1.5 ${
                soundEnabled
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
              title={soundEnabled ? t.soundOn : t.soundOff}
            >
              {soundEnabled ? (
                <>
                  <Volume2 className="w-4 h-4 text-emerald-600" />
                  <span className="hidden xl:inline">{t.soundOn}</span>
                </>
              ) : (
                <>
                  <VolumeX className="w-4 h-4 text-slate-500" />
                  <span className="hidden xl:inline">{t.soundOff}</span>
                </>
              )}
            </button>

            {/* Language Switcher */}
            <button
              type="button"
              onClick={onToggleLanguage}
              className="wl-lang-btn"
              title="Switch Language"
            >
              <Globe className="w-4 h-4 text-indigo-600" />
              <span>{language === 'en' ? 'हिन्दी' : 'English'}</span>
            </button>

            {/* Telegram Button */}
            <a
              href="https://t.me/+lWlvfbR1BkI5YjFl"
              target="_blank"
              rel="noreferrer noopener"
              className="wl-telegram-btn"
            >
              <Send className="w-4 h-4 fill-white" />
              <span>{t.joinTelegram}</span>
            </a>
          </div>

          {/* Mobile Telegram quick link */}
          <a
            href="https://t.me/+lWlvfbR1BkI5YjFl"
            target="_blank"
            rel="noreferrer noopener"
            className="wl-mobile-telegram lg:hidden"
            aria-label="Telegram"
          >
            <Send className="w-5 h-5 fill-white" />
          </a>
        </div>
      </div>
    </header>
  );
};
