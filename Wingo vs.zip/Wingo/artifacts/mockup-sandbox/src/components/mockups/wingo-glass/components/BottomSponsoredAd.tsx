import React, { useState, useEffect } from 'react';
import { ExternalLink, Flame } from 'lucide-react';
import { Language } from '../types';

interface BottomSponsoredAdProps {
  language: Language;
}

export const BottomSponsoredAd: React.FC<BottomSponsoredAdProps> = ({ language }) => {
  const AD_URL =
    'https://www.k00097.com/#/pages/login/register?invitationCode=1424650754&regSourceFlag=1';
  const ICON_URL =
    'https://wingolottery.com/wp-content/uploads/2026/09/wingo-lottery.webp';
  const CLOSE_KEY = 'wingo-bottom-sponsored-ad-closed';

  const [isClosed, setIsClosed] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem(CLOSE_KEY) === '1';
    } catch {
      return false;
    }
  });

  const [iconError, setIconError] = useState(false);

  const isHindi = language === 'hi';

  const copy = isHindi
    ? {
        label: 'विज्ञापन',
        eyebrow: 'WINGO × 00097',
        title: 'WinGo खेलना चाहते हैं?',
        detail: '00097 पर रजिस्टर करके गेम देखें',
        button: 'WinGo के लिए रजिस्टर करें',
        close: 'विज्ञापन बंद करें',
      }
    : {
        label: 'ADVERTISEMENT',
        eyebrow: 'WINGO × 00097',
        title: 'Ready to explore WinGo?',
        detail: 'Register with 00097 to view available games',
        button: 'Explore WinGo',
        close: 'Close advertisement',
      };

  const handleClose = () => {
    setIsClosed(true);
    try {
      sessionStorage.setItem(CLOSE_KEY, '1');
    } catch {
      // ignore
    }
  };

  const handleReopen = () => {
    setIsClosed(false);
    try {
      sessionStorage.removeItem(CLOSE_KEY);
    } catch {
      // ignore
    }
  };

  if (isClosed) {
    return (
      <div className="fixed bottom-3 left-4 z-40">
        <button
          type="button"
          onClick={handleReopen}
          className="px-3 py-1.5 rounded-full bg-slate-900/80 backdrop-blur-md text-amber-300 hover:text-white text-[11px] font-black border border-white/20 shadow-lg transition-all hover:scale-105 flex items-center gap-1.5"
          title="Show WinGo 00097 Sponsor"
        >
          <Flame className="w-3.5 h-3.5 fill-amber-300 text-amber-300" />
          <span>{copy.eyebrow}</span>
        </button>
      </div>
    );
  }

  return (
    <>
      {/* Spacer so bottom footer isn't covered */}
      <div className="h-28 sm:h-24 w-full" aria-hidden="true" />

      {/* Uploaded Sponsored Ad Container */}
      <aside
        id="wingo-bottom-sponsored-ad"
        className="wingo-bottom-ad-container"
        aria-label={copy.label}
      >
        <div className="wba-content">
          <span className="wba-icon-wrap">
            {!iconError ? (
              <img
                className="wba-icon"
                src={ICON_URL}
                alt="WinGo Lottery"
                width={58}
                height={58}
                onError={() => setIconError(true)}
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white">
                <Flame className="w-7 h-7 fill-amber-300 text-amber-300" />
              </div>
            )}
          </span>

          <span className="wba-copy">
            <span className="wba-meta">
              <span className="wba-label">{copy.label}</span>
              <span className="wba-eyebrow">{copy.eyebrow}</span>
            </span>
            <strong className="wba-title">{copy.title}</strong>
            <span className="wba-detail">{copy.detail}</span>
          </span>

          <a
            className="wba-button"
            href={AD_URL}
            target="_blank"
            rel="nofollow sponsored noopener noreferrer"
          >
            <span className="wba-button-text">{copy.button}</span>
            <span className="wba-arrow" aria-hidden="true">
              ↗
            </span>
          </a>
        </div>

        <button
          className="wba-close"
          type="button"
          onClick={handleClose}
          aria-label={copy.close}
        >
          ×
        </button>
      </aside>
    </>
  );
};
