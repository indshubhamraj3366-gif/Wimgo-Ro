import React from 'react';
import { HelpCircle, ChevronDown } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';

interface FaqSectionProps {
  language: Language;
}

export const FaqSection: React.FC<FaqSectionProps> = ({ language }) => {
  const t = translations[language];

  return (
    <section id="faq" className="wl-section">
      <div className="wl-container">
        <div className="wl-section-head">
          <div className="wl-pill mb-2">
            <HelpCircle className="w-4 h-4 text-indigo-600" />
            <span>KNOWLEDGE BASE</span>
          </div>
          <h2>{t.faqTitle}</h2>
        </div>

        <div className="wl-faq-list">
          <details open>
            <summary>
              <span>{t.faq1Q}</span>
              <ChevronDown className="w-4 h-4 text-slate-400 transition-transform group-open:rotate-180" />
            </summary>
            <p>{t.faq1A}</p>
          </details>

          <details>
            <summary>
              <span>{t.faq2Q}</span>
              <ChevronDown className="w-4 h-4 text-slate-400" />
            </summary>
            <p>{t.faq2A}</p>
          </details>

          <details>
            <summary>
              <span>{t.faq3Q}</span>
              <ChevronDown className="w-4 h-4 text-slate-400" />
            </summary>
            <p>{t.faq3A}</p>
          </details>

          <details>
            <summary>
              <span>{t.faq4Q}</span>
              <ChevronDown className="w-4 h-4 text-slate-400" />
            </summary>
            <p>{t.faq4A}</p>
          </details>
        </div>
      </div>
    </section>
  );
};
