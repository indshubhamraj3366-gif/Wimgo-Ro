/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { ArrowLeft } from 'lucide-react';
import { Language, PendingPrediction, PeriodType, PredictionData, PredictionLogEntry } from './types';
import { translations } from './translations';
import {
  PERIOD_SECONDS,
  formatCountdown,
  getSecondsLeft,
} from './engine/wingoEngine';
import { fetchLiveWingoData } from './services/apiService';
import { Header } from './components/Header';
import { MobileDrawer } from './components/MobileDrawer';
import { HeroPrediction } from './components/HeroPrediction';
import { PeriodTabs } from './components/PeriodTabs';
import { LiveResultsSection } from './components/LiveResultsSection';
import { ReadingGuide } from './components/ReadingGuide';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';
import { ProgramHome } from './components/ProgramHome';
import { PredictionLogModal } from './components/PredictionLogModal';
import { ResultPopup } from './components/ResultPopup';
import { ProfileModal } from './components/ProfileModal';
import { playTickBeep } from './utils/sound';

type AppView = 'programs' | 'prediction';

interface AppRoute {
  language: Language;
  view: AppView;
  period: PeriodType;
}

type LoadState = 'loading' | 'error' | 'ready';

function readAppRoute(pathname: string): AppRoute {
  const parts = pathname.split('/').filter(Boolean);
  const language: Language = parts[0]?.toLowerCase() === 'hi' ? 'hi' : 'en';
  const routeParts = language === 'hi' ? parts.slice(1) : parts;
  const selectedPeriod = routeParts[0]?.toLowerCase() === 'prediction' ? routeParts[1] : undefined;

  if (selectedPeriod === '30s' || selectedPeriod === '1m') {
    return { language, view: 'prediction', period: selectedPeriod };
  }

  return { language, view: 'programs', period: '1m' };
}

function getAppPath(view: AppView, period: PeriodType, language: Language): string {
  const languagePrefix = language === 'hi' ? '/hi' : '';
  return view === 'prediction'
    ? `${languagePrefix}/prediction/${period}`
    : languagePrefix || '/';
}

export default function App() {
  const [route, setRoute] = useState<AppRoute>(() => readAppRoute(window.location.pathname));
  const { language, view, period: currentPeriod } = route;
  const [soundEnabled, setSoundEnabled] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isPredictionLogOpen, setIsPredictionLogOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [sessionLogs, setSessionLogs] = useState<PredictionLogEntry[]>([]);
  const [resolvedResult, setResolvedResult] = useState<PredictionLogEntry | null>(null);
  const closeResolvedResult = useCallback(() => setResolvedResult(null), []);

  const toggleLanguage = useCallback(() => {
    const nextLanguage: Language = language === 'en' ? 'hi' : 'en';
    const nextRoute = { ...route, language: nextLanguage };
    setRoute(nextRoute);
    window.history.pushState(null, '', getAppPath(nextRoute.view, nextRoute.period, nextRoute.language));
  }, [language, route]);

  // Keep the selected program and language in sync with browser history and direct links.
  useEffect(() => {
    const syncRouteFromPath = () => {
      const nextRoute = readAppRoute(window.location.pathname);
      setRoute(nextRoute);
      currentPeriodRef.current = nextRoute.period;
      currentViewRef.current = nextRoute.view;
      if (nextRoute.view === 'programs') {
        setIsDrawerOpen(false);
        setIsPredictionLogOpen(false);
        setIsProfileOpen(false);
        setResolvedResult(null);
      }
    };

    window.addEventListener('popstate', syncRouteFromPath);
    return () => window.removeEventListener('popstate', syncRouteFromPath);
  }, []);

  useEffect(() => {
    document.documentElement.lang = language;
  }, [language]);

  useEffect(() => {
    if (!isDrawerOpen && !isPredictionLogOpen && !isProfileOpen && !resolvedResult) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = previousOverflow;
    };
  }, [isDrawerOpen, isPredictionLogOpen, isProfileOpen, resolvedResult]);

  // Prediction data store for each period
  const [dataStore, setDataStore] = useState<Partial<Record<PeriodType, PredictionData>>>({});
  const dataStoreRef = useRef(dataStore);
  dataStoreRef.current = dataStore;
  const [loadState, setLoadState] = useState<Record<PeriodType, LoadState>>({
    '30s': 'loading',
    '1m': 'loading',
  });

  // Countdown seconds for each period
  const [countdownMap, setCountdownMap] = useState<Record<PeriodType, number>>(() => ({
    '30s': getSecondsLeft(PERIOD_SECONDS['30s']),
    '1m': getSecondsLeft(PERIOD_SECONDS['1m']),
  }));

  const soundRef = useRef(soundEnabled);
  soundRef.current = soundEnabled;

  const currentPeriodRef = useRef(currentPeriod);
  currentPeriodRef.current = currentPeriod;
  const currentViewRef = useRef(view);
  currentViewRef.current = view;
  const pendingByPeriodRef = useRef<Partial<Record<PeriodType, Map<string, PendingPrediction>>>>({});
  const inFlightPeriodsRef = useRef(new Set<PeriodType>());

  // Resolve only the exact pending issue returned by the live API.
  const loadPeriodData = useCallback(async (period: PeriodType) => {
    if (inFlightPeriodsRef.current.has(period)) return;
    inFlightPeriodsRef.current.add(period);
    setLoadState((prev) => ({
      ...prev,
      [period]: dataStoreRef.current[period] ? prev[period] : 'loading',
    }));
    try {
      const liveData = await fetchLiveWingoData(period);
      const pendingPredictions = pendingByPeriodRef.current[period];
      const results: PredictionLogEntry[] = [];
      const resolvedIssues: string[] = [];

      if (pendingPredictions) {
        for (const [issue, pending] of pendingPredictions) {
          const actual = liveData.history.find((row) => row.issue === issue);
          if (!actual && BigInt(liveData.history[0].issue) > BigInt(issue)) {
            throw new Error(`Pending draw ${issue} is missing from live history`);
          }
          if (!actual) continue;
          results.push({
            period: `${period} · ${actual.issue}`,
            prediction: pending.predictedSize,
            actualResult: actual.size,
            status: pending.predictedSize === actual.size ? 'WIN' : 'LOSS',
            timestamp: Date.now(),
          });
          resolvedIssues.push(issue);
        }
        resolvedIssues.forEach((issue) => pendingPredictions.delete(issue));
      }

      if (results.length) {
        setSessionLogs((previous) => (
          [...previous, ...results.filter(
            (result) => !previous.some((entry) => entry.period === result.period),
          )].slice(-100)
        ));
        if (currentViewRef.current === 'prediction') {
          setResolvedResult(results[results.length - 1]);
        }
      }

      if (
        currentViewRef.current === 'prediction' &&
        currentPeriodRef.current === period &&
        liveData.signal
      ) {
        const predictions = pendingByPeriodRef.current[period] ?? new Map<string, PendingPrediction>();
        if (!predictions.has(liveData.targetIssue)) {
          predictions.set(liveData.targetIssue, {
            period,
            predictionPeriod: liveData.targetIssue,
            predictedSize: liveData.signal,
            confidence: liveData.confidence,
            timestamp: Date.now(),
          });
          pendingByPeriodRef.current[period] = predictions;
        }
      }

      setDataStore((prev) => ({
        ...prev,
        [period]: liveData,
      }));
      setLoadState((prev) => ({ ...prev, [period]: 'ready' }));
    } catch (error) {
      console.warn(`[WinGo] Live ${period} data is unavailable:`, error);
      setLoadState((prev) => ({ ...prev, [period]: 'error' }));
    } finally {
      inFlightPeriodsRef.current.delete(period);
    }
  }, []);

  const openPrediction = useCallback((period: PeriodType) => {
    const nextRoute: AppRoute = { language, view: 'prediction', period };
    currentPeriodRef.current = period;
    currentViewRef.current = 'prediction';
    setRoute(nextRoute);
    window.history.pushState(null, '', getAppPath(nextRoute.view, nextRoute.period, nextRoute.language));
    loadPeriodData(period);
  }, [language, loadPeriodData]);

  const selectPredictionPeriod = useCallback((period: PeriodType) => {
    const nextRoute: AppRoute = { ...route, period };
    currentPeriodRef.current = period;
    currentViewRef.current = nextRoute.view;
    setRoute(nextRoute);
    if (route.view === 'prediction') {
      window.history.pushState(null, '', getAppPath('prediction', period, language));
    }
    loadPeriodData(period);
  }, [language, loadPeriodData, route]);

  const returnToPrograms = useCallback(() => {
    const nextRoute: AppRoute = { ...route, view: 'programs' };
    currentViewRef.current = 'programs';
    setRoute(nextRoute);
    setIsDrawerOpen(false);
    setIsPredictionLogOpen(false);
    setIsProfileOpen(false);
    setResolvedResult(null);
    window.history.pushState(null, '', getAppPath(nextRoute.view, nextRoute.period, nextRoute.language));
  }, [route]);

  // Fetch initial data for each game, then keep the selected game current.
  useEffect(() => {
    loadPeriodData('30s');
    loadPeriodData('1m');
  }, [loadPeriodData]);

  useEffect(() => {
    const intervalId = window.setInterval(() => {
      loadPeriodData(currentPeriodRef.current);
    }, 2000);
    return () => window.clearInterval(intervalId);
  }, [loadPeriodData]);

  // Refresh active period prediction
  const refreshActivePeriod = useCallback(async () => {
    setIsRefreshing(true);
    try {
      await loadPeriodData(currentPeriodRef.current);
    } finally {
      setIsRefreshing(false);
    }
  }, [loadPeriodData]);

  // Main countdown timer loop
  useEffect(() => {
    const intervalId = setInterval(() => {
      const nextCountdowns: Record<PeriodType, number> = {
        '30s': 0,
        '1m': 0,
      };

      (['30s', '1m'] as PeriodType[]).forEach((p) => {
        const left = getSecondsLeft(PERIOD_SECONDS[p]);
        nextCountdowns[p] = left;

        // Sound cue for active period under 5s
        if (p === currentPeriodRef.current && soundRef.current) {
          if (left <= 5 && left >= 1) {
            playTickBeep(false);
          } else if (left === 0) {
            playTickBeep(true);
          }
        }

      });

      setCountdownMap(nextCountdowns);
    }, 1000);

    return () => clearInterval(intervalId);
  }, []);

  // Format countdown map for tabs
  const formattedCountdownMap: Record<PeriodType, string> = {
    '30s': formatCountdown(countdownMap['30s']),
    '1m': formatCountdown(countdownMap['1m']),
  };

  const currentData = dataStore[currentPeriod];

  return (
    <div className="wingo-dark-glass min-h-[100dvh] flex flex-col selection:bg-rose-500 selection:text-white" lang={language}>
      {view === 'programs' ? (
        <ProgramHome
          language={language}
          onToggleLanguage={toggleLanguage}
          onSelectPeriod={openPrediction}
        />
      ) : (
        <>
          <a href="#live-prediction" className="wl-skip-link">
            Skip to main content
          </a>

          <Header
            language={language}
            onToggleLanguage={toggleLanguage}
            onHome={returnToPrograms}
            soundEnabled={soundEnabled}
            onToggleSound={() => setSoundEnabled((prev) => !prev)}
            onOpenDrawer={() => setIsDrawerOpen(true)}
          />

          <div className="wl-prediction-return">
            <button type="button" className="wl-program-back" onClick={returnToPrograms}>
              <ArrowLeft className="h-4 w-4" />
              {language === 'hi' ? 'प्रोग्राम चुनें' : 'All programs'}
            </button>
          </div>

          <MobileDrawer
            isOpen={isDrawerOpen}
            onClose={() => setIsDrawerOpen(false)}
            language={language}
            onToggleLanguage={toggleLanguage}
            currentPeriod={currentPeriod}
            onSelectPeriod={selectPredictionPeriod}
            onOpenPredictionLog={() => setIsPredictionLogOpen(true)}
            onOpenProfile={() => setIsProfileOpen(true)}
            onHome={returnToPrograms}
            countdownMap={formattedCountdownMap}
          />

          <main className="wl-site-content grow">
            {currentData && loadState[currentPeriod] === 'ready' ? (
              <>
                <HeroPrediction
                  data={currentData}
                  countdown={countdownMap[currentPeriod]}
                  language={language}
                  onRefresh={refreshActivePeriod}
                  isRefreshing={isRefreshing}
                  onOpenPredictionLog={() => setIsPredictionLogOpen(true)}
                />

                <section className="py-6 border-y border-slate-200/80 bg-white/70 backdrop-blur-xs">
                  <div className="wl-container">
                    <PeriodTabs
                      currentPeriod={currentPeriod}
                      onSelectPeriod={selectPredictionPeriod}
                      language={language}
                      countdownMap={formattedCountdownMap}
                      onOpenPredictionLog={() => setIsPredictionLogOpen(true)}
                    />
                  </div>
                </section>

                <LiveResultsSection data={currentData} language={language} />
                <ReadingGuide language={language} />
                <FaqSection language={language} />
              </>
            ) : (
              <div className="wl-container py-16 sm:py-24">
                <div className="wl-live-card mx-auto max-w-xl text-center">
                  <h2 className="text-xl sm:text-2xl font-black text-white">
                    {loadState[currentPeriod] === 'error'
                      ? translations[language].liveDataUnavailable
                      : translations[language].loadingLiveData}
                  </h2>
                  <p className="mt-3 text-sm text-slate-300">
                    {translations[language].liveDataMessage}
                  </p>
                  {loadState[currentPeriod] === 'error' && (
                    <button
                      type="button"
                      onClick={refreshActivePeriod}
                      className="wl-btn wl-btn-primary mt-5"
                      disabled={isRefreshing}
                    >
                      {isRefreshing
                        ? translations[language].refreshing
                        : translations[language].retryLiveData}
                    </button>
                  )}
                </div>
              </div>
            )}
          </main>

          <Footer language={language} />

          <PredictionLogModal
            isOpen={isPredictionLogOpen}
            onClose={() => setIsPredictionLogOpen(false)}
            entries={sessionLogs}
            language={language}
          />
          {isProfileOpen && (
            <ProfileModal
              language={language}
              period={currentPeriod}
              resolvedCount={sessionLogs.length}
              onClose={() => setIsProfileOpen(false)}
            />
          )}
          {resolvedResult && (
            <ResultPopup
              result={resolvedResult}
              language={language}
              onClose={closeResolvedResult}
            />
          )}
        </>
      )}
    </div>
  );
}
