export type PeriodType = '30s' | '1m';

export type SizePrediction = 'Big' | 'Small';

export type PredictionState = 'BET' | 'LOW_CONFIDENCE';

export type ColorType = 'Green' | 'Red' | 'Violet';

export interface HistoryRow {
  issue: string;
  number: number;
  size: SizePrediction;
  colors: ColorType[];
  time: string;
}

export interface PredictionData {
  period: PeriodType;
  periodLabel: string;
  seconds: number;
  targetIssue: string;
  signal: SizePrediction | null;
  number: number | null;
  confidence: number;
  predictionState: PredictionState;
  lookbackWindow: number;
  history: HistoryRow[];
}

export interface PredictionLogEntry {
  period: string;
  prediction: SizePrediction;
  actualResult: SizePrediction;
  status: 'WIN' | 'LOSS';
  timestamp: number;
}

export interface PendingPrediction {
  period: PeriodType;
  predictionPeriod: string;
  predictedSize: SizePrediction;
  confidence: number;
  timestamp: number;
}

export type Language = 'en' | 'hi';
