export const ADMIN_CONTACT_EMAIL = 'vip-support@wingolottery.com';
export const TELEGRAM_JOIN_URL = 'https://t.me/+lWlvfbR1BkI5YjFl';
