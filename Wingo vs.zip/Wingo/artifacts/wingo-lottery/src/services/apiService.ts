import { ColorType, HistoryRow, PeriodType, PredictionData, SizePrediction } from '../types';
import { PERIOD_NAMES, PERIOD_SECONDS, getSecondsLeft } from '../engine/wingoEngine';

export const API_ENDPOINTS: Record<PeriodType, string> = {
  '30s': 'https://sky-predictor-1012593186417.asia-southeast1.run.app/api/wingo-history-30s-1000',
  '1m': 'https://sky-predictor-1012593186417.asia-southeast1.run.app/api/wingo-history-1m-1000',
};

export interface ApiHistoryItem {
  issueNumber: string;
  number: number;
  size: string; // 'big' | 'small'
  colour: string; // 'green' | 'red' | 'green,violet' | 'red,violet'
  time: string; // 'HH:MM:SS'
}

export interface ApiResponse {
  code: number;
  msg: string;
  data?: {
    list: ApiHistoryItem[];
  };
}

export function parseApiColours(colourStr: string, num: number): ColorType[] {
  const str = (colourStr || '').toLowerCase();
  if (str.includes('violet')) {
    if (str.includes('green') || num === 5) {
      return ['Green', 'Violet'];
    }
    if (str.includes('red') || num === 0) {
      return ['Red', 'Violet'];
    }
  }
  if (num === 0) return ['Red', 'Violet'];
  if (num === 5) return ['Green', 'Violet'];
  if (str.includes('green') || [1, 3, 7, 9].includes(num)) {
    return ['Green'];
  }
  if (str.includes('red') || [2, 4, 6, 8].includes(num)) {
    return ['Red'];
  }
  return ['Green'];
}

export function getNextTargetIssue(latestIssueNumber: string): string {
  try {
    return String(BigInt(latestIssueNumber) + 1n);
  } catch {
    return String(Number(latestIssueNumber) + 1);
  }
}

const ANALYSIS_WINDOWS = [20, 50, 100, 200, 500] as const;
const RECENCY_DECAY = 0.94;
const MIN_CONFIDENCE = 56;
const MIN_CONSENSUS = 0.6;
const SIGNAL_WEIGHTS = {
  shortTerm: 0.2,
  longTerm: 0.15,
  recency: 0.2,
  transition: 0.2,
  pattern: 0.15,
  baseline: 0.1,
};

function bigRate(rows: HistoryRow[]): number {
  if (!rows.length) return 0.5;
  const big = rows.reduce((count, row) => count + Number(row.size === 'Big'), 0);
  return (big + 0.5) / (rows.length + 1);
}

function weightedBigRate(rows: HistoryRow[]): number {
  let big = 0;
  let total = 0;
  rows.forEach((row, age) => {
    const weight = RECENCY_DECAY ** age;
    if (row.size === 'Big') big += weight;
    total += weight;
  });
  return total ? big / total : 0.5;
}

function transitionBigRate(history: HistoryRow[], prior: number): number {
  const latest = history[0]?.size;
  if (!latest) return prior;
  let big = 0;
  let total = 0;
  for (let index = 1; index < history.length; index++) {
    if (history[index].size === latest) {
      total++;
      if (history[index - 1].size === 'Big') big++;
    }
  }
  return (big + prior * 6) / (total + 6);
}

function patternBigRate(history: HistoryRow[], prior: number): number {
  const context = history.slice(0, 3).map((row) => row.size);
  if (context.length < 3) return prior;
  let big = 0;
  let total = 0;
  for (let index = 1; index + context.length < history.length; index++) {
    const match = context.every((size, offset) => history[index + offset].size === size);
    if (match) {
      total++;
      if (history[index - 1].size === 'Big') big++;
    }
  }
  return (big + prior * 8) / (total + 8);
}

function getSignal(rate: number): SizePrediction {
  return rate >= 0.5 ? 'Big' : 'Small';
}

function getNumber(history: HistoryRow[], signal: SizePrediction): number | null {
  const counts = Array<number>(10).fill(0);
  history.forEach((row, age) => {
    if (row.size === signal) counts[row.number] += RECENCY_DECAY ** age;
  });
  const first = signal === 'Big' ? 5 : 0;
  const last = signal === 'Big' ? 9 : 4;
  const best = Array.from({ length: last - first + 1 }, (_, index) => first + index)
    .sort((left, right) => counts[right] - counts[left])[0];
  return counts[best] > 0 ? best : null;
}

export function deriveSignalFromHistory(history: HistoryRow[]): {
  signal: SizePrediction | null;
  number: number | null;
  confidence: number;
  predictionState: PredictionData['predictionState'];
  lookbackWindow: number;
} {
  const available = history.slice(0, 500);
  const windowRates = ANALYSIS_WINDOWS
    .filter((window) => available.length >= window)
    .map((window) => bigRate(available.slice(0, window)));
  const shortTerm = bigRate(available.slice(0, Math.min(20, available.length)));
  const longTerm = bigRate(available);
  const recency = weightedBigRate(available);
  const transition = transitionBigRate(available, longTerm);
  const pattern = patternBigRate(available, longTerm);
  const baseline = windowRates.length
    ? windowRates.reduce((sum, rate) => sum + rate, 0) / windowRates.length
    : longTerm;
  const signals = [shortTerm, longTerm, recency, transition, pattern, baseline];
  const weights = Object.values(SIGNAL_WEIGHTS);
  const combined = signals.reduce((sum, rate, index) => sum + rate * weights[index], 0);
  const direction = getSignal(combined);
  const agreement = signals.filter((rate) => getSignal(rate) === direction).length / signals.length;
  const confidence = Math.round(Math.max(50, Math.min(100, 50 + Math.abs(combined - 0.5) * 100)));
  const predictionState = available.length >= 20 && confidence >= MIN_CONFIDENCE && agreement >= MIN_CONSENSUS
    ? 'BET'
    : 'LOW_CONFIDENCE';

  return {
    signal: direction,
    number: getNumber(available, direction),
    confidence,
    predictionState,
    lookbackWindow: available.length,
  };
}

const newestIssueByPeriod: Partial<Record<PeriodType, { issue: string; observedAt: number }>> = {};
const REQUEST_TIMEOUT_MS = 8000;

function issueIsOlder(candidate: string, reference: string): boolean {
  try {
    return BigInt(candidate) < BigInt(reference);
  } catch {
    return false;
  }
}

export async function fetchLiveWingoData(period: PeriodType): Promise<PredictionData> {
  const endpoint = API_ENDPOINTS[period];
  let lastError: unknown;

  for (let attempt = 0; attempt < 2; attempt++) {
    const controller = new AbortController();
    const timeoutId = window.setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
    try {
      const response = await fetch(endpoint, {
        method: 'GET',
        headers: { Accept: 'application/json' },
        cache: 'no-store',
        signal: controller.signal,
      });
      if (!response.ok) throw new Error(`API responded with HTTP ${response.status}`);

      const json: ApiResponse = await response.json();
      if (json.code !== 0 || !Array.isArray(json.data?.list) || !json.data.list.length) {
        throw new Error('Invalid API data payload');
      }

      const seenIssues = new Set<string>();
      const history: HistoryRow[] = [];
      for (const item of json.data.list) {
        const issue = String(item.issueNumber ?? '');
        const number = Number(item.number);
        if (!/^\d+$/.test(issue) || !Number.isInteger(number) || number < 0 || number > 9) {
          throw new Error('Invalid draw row from live API');
        }
        if (seenIssues.has(issue)) continue;
        seenIssues.add(issue);
        history.push({
          issue,
          number,
          size: number >= 5 ? 'Big' : 'Small',
          colors: parseApiColours(item.colour, number),
          time: String(item.time ?? ''),
        });
        if (history.length === 500) break;
      }

      if (!history.length) throw new Error('Live API returned no unique draw rows');
      history.sort((left, right) => {
        const leftIssue = BigInt(left.issue);
        const rightIssue = BigInt(right.issue);
        return leftIssue > rightIssue ? -1 : leftIssue < rightIssue ? 1 : 0;
      });
      const latestIssue = history[0].issue;
      const previous = newestIssueByPeriod[period];
      if (previous && issueIsOlder(latestIssue, previous.issue)) {
        throw new Error('Live API returned stale history');
      }
      if (previous?.issue === latestIssue) {
        if (Date.now() - previous.observedAt > PERIOD_SECONDS[period] * 3000) {
          throw new Error('Live API history has stopped advancing');
        }
      } else {
        newestIssueByPeriod[period] = { issue: latestIssue, observedAt: Date.now() };
      }

      const prediction = deriveSignalFromHistory(history);
      return {
        period,
        periodLabel: PERIOD_NAMES[period],
        seconds: getSecondsLeft(PERIOD_SECONDS[period]),
        targetIssue: getNextTargetIssue(latestIssue),
        ...prediction,
        history,
      };
    } catch (error) {
      lastError = error;
      if (attempt === 0) continue;
    } finally {
      window.clearTimeout(timeoutId);
    }
  }

  console.warn(`[WinGo API] Error fetching ${period} data:`, lastError);
  throw lastError instanceof Error ? lastError : new Error('Live data unavailable');
}
