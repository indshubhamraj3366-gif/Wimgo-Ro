import {createRoot} from 'react-dom/client';
import './index.css';
import './dark-glass.css';
import App from './App.tsx';

createRoot(document.getElementById('root')!).render(<App />);
