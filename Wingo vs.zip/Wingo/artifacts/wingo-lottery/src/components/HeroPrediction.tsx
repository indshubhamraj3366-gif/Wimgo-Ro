import React, { useEffect, useRef, useState } from 'react';
import {
  RotateCw,
  Copy,
  Check,
  TrendingUp,
  ShieldCheck,
  BarChart3,
  Clock,
  Sparkles,
} from 'lucide-react';
import { Language, PredictionData } from '../types';
import { translations } from '../translations';
import { formatCountdown, formatPeriodNumber } from '../engine/wingoEngine';

interface HeroPredictionProps {
  data: PredictionData;
  countdown: number;
  language: Language;
  onRefresh: () => void;
  isRefreshing: boolean;
  onOpenPredictionLog: () => void;
}

export const HeroPrediction: React.FC<HeroPredictionProps> = ({
  data,
  countdown,
  language,
  onRefresh,
  isRefreshing,
  onOpenPredictionLog,
}) => {
  const t = translations[language];
  const [copied, setCopied] = useState(false);
  const copyTimeoutRef = useRef<number | null>(null);
  const displayIssue = formatPeriodNumber(data.targetIssue);

  useEffect(() => () => {
    if (copyTimeoutRef.current !== null) window.clearTimeout(copyTimeoutRef.current);
  }, []);

  const handleCopyIssue = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(displayIssue);
      setCopied(true);
      if (copyTimeoutRef.current !== null) window.clearTimeout(copyTimeoutRef.current);
      copyTimeoutRef.current = window.setTimeout(() => setCopied(false), 2000);
    }
  };

  const isUrgent = countdown <= 10;

  return (
    <section id="live-prediction" className="wl-hero">
      <div className="wl-container">
        <div className="wl-hero-grid">
          {/* Left Column: Hero Copy */}
          <div className="wl-hero-copy">
            <div className="wl-pill">
              <Sparkles className="w-4 h-4 text-rose-400" />
              <span>{t.heroEyebrow}</span>
            </div>

            <h1>
              {t.heroTitlePrefix}{' '}
              <span className="wl-gradient-text">{t.heroTitleGradient}</span>{' '}
              {t.heroTitleSuffix}
            </h1>

            <p className="wl-lead">{t.heroSubtitle}</p>

            <div className="wl-hero-actions">
              <a href="#draw-history" className="wl-btn wl-btn-primary">
                <TrendingUp className="w-4 h-4" />
                <span>{t.navHistory}</span>
              </a>

              <button type="button" onClick={onOpenPredictionLog} className="wl-btn wl-btn-soft">
                <BarChart3 className="w-4 h-4" />
                <span>{language === 'hi' ? 'प्रेडिक्शन लॉग' : 'Prediction Logs'}</span>
              </button>
            </div>

            <div className="wl-trust-row">
              <span>
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                {t.modelBadge}
              </span>
              <span>
                <ShieldCheck className="w-4 h-4 text-rose-400" />
                {t.activeUsersBadge}
              </span>
              <span>
                <Clock className="w-4 h-4 text-emerald-500" />
                {t.istSyncedBadge}
              </span>
            </div>
          </div>

          {/* Right Column: Live Card (From Uploaded Design) */}
          <div className="wl-hero-visual">
            <div className="wl-live-card">
              {/* Card Top */}
              <div className="wl-live-top">
                <div>
                  <span className="wl-live-label">
                    <span className="relative flex h-2.5 w-2.5 mr-1">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                    </span>
                    {t.liveCardTitle}
                  </span>
                  <h3>{data.periodLabel}</h3>
                </div>

                <div className="flex items-center gap-2">
                  <div className="wl-live-badge">
                    <span className="pulse-dot"></span>
                    <span>{t.badge}</span>
                  </div>

                </div>
              </div>

              {/* Active Period & Issue */}
              <div className="wl-draw-box">
                <div>
                  <span>{t.drawIssue}</span>
                  <div className="flex items-center gap-2 mt-1">
                    <strong className="tracking-wide font-mono text-indigo-950">
                      #{displayIssue}
                    </strong>
                    <button
                      type="button"
                      onClick={handleCopyIssue}
                      className="p-1.5 rounded-md hover:bg-indigo-100 text-indigo-600 transition-colors"
                      title="Copy Issue Number"
                    >
                      {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <span>{t.timeRemaining}</span>
                  <div className={`wl-countdown ${isUrgent ? 'is-urgent' : ''}`}>
                    {formatCountdown(countdown)}
                  </div>
                </div>
              </div>

              {/* Big/Small signal and number prediction */}
              <div className="wl-signal-grid">
                <div>
                  <span>{t.signal}</span>
                  <strong className={data.predictionState === 'BET' ? 'text-rose-400' : 'text-amber-300'}>
                    {data.signal
                      ? data.signal === 'Big' ? t.big : t.small
                      : language === 'hi' ? 'कम भरोसा' : 'LOW CONFIDENCE'}
                  </strong>
                </div>

                <div>
                  <span>{t.recommendedNumber}</span>
                  <strong className="text-rose-400 text-xl font-black">
                    {data.number ?? '—'}
                  </strong>
                </div>
                <div>
                  <span>{t.confidence}</span>
                  <strong className="text-white text-xl font-black">{data.confidence}%</strong>
                </div>
              </div>

              {/* Card Bottom Meta */}
              <div className="wl-live-bottom">
                <button
                  type="button"
                  onClick={onRefresh}
                  disabled={isRefreshing}
                  className="wl-mini-btn"
                >
                  <RotateCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
                  <span>{isRefreshing ? t.refreshing : t.refreshSignal}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
