import React, { useEffect } from 'react';
import { CheckCircle2, XCircle } from 'lucide-react';
import { Language, PredictionLogEntry } from '../types';

interface ResultPopupProps {
  result: PredictionLogEntry;
  language: Language;
  onClose: () => void;
}

export function ResultPopup({ result, language, onClose }: ResultPopupProps) {
  useEffect(() => {
    const timeoutId = window.setTimeout(onClose, 3000);
    return () => window.clearTimeout(timeoutId);
  }, [onClose, result.timestamp]);

  const isWin = result.status === 'WIN';

  return (
    <div className="wl-result-backdrop" role="presentation" onClick={onClose}>
      <section
        className="wl-result-popup"
        role="dialog"
        aria-modal="true"
        aria-labelledby="wl-result-title"
        onClick={(event) => event.stopPropagation()}
      >
        <div className={`wl-result-mark ${isWin ? 'is-win' : 'is-loss'}`}>
          {isWin ? <CheckCircle2 aria-hidden="true" /> : <XCircle aria-hidden="true" />}
        </div>
        <p className="wl-result-kicker">{language === 'hi' ? 'परिणाम सत्यापित' : 'RESULT VERIFIED'}</p>
        <h2 id="wl-result-title">{isWin ? 'WIN' : 'LOSS'}</h2>
        <dl className="wl-result-details">
          <div><dt>{language === 'hi' ? 'पीरियड' : 'Period'}</dt><dd>#{result.period}</dd></div>
          <div><dt>{language === 'hi' ? 'अनुमान' : 'Prediction'}</dt><dd>{result.prediction}</dd></div>
          <div><dt>{language === 'hi' ? 'वास्तविक परिणाम' : 'Actual Result'}</dt><dd>{result.actualResult}</dd></div>
        </dl>
        <button type="button" className="wl-result-action" onClick={onClose}>
          {language === 'hi' ? 'अगला विश्लेषण' : 'ANALYSE NEXT'}
        </button>
      </section>
    </div>
  );
}
