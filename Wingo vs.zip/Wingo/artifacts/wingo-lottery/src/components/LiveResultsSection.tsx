import React from 'react';
import { History } from 'lucide-react';
import { Language, PredictionData } from '../types';
import { translations } from '../translations';
import { formatPeriodNumber } from '../engine/wingoEngine';

interface LiveResultsSectionProps {
  data: PredictionData;
  language: Language;
}

export const LiveResultsSection: React.FC<LiveResultsSectionProps> = ({ data, language }) => {
  const t = translations[language];
  const rows = data.history.slice(0, 20);

  const getBallClass = (number: number) => {
    if (number === 0) return 'wl-number-ball wl-number-red-violet';
    if (number === 5) return 'wl-number-ball wl-number-green-violet';
    if ([1, 3, 7, 9].includes(number)) return 'wl-number-ball wl-number-green';
    return 'wl-number-ball wl-number-red';
  };

  return (
    <section id="draw-history" className="wl-section wl-soft-band">
      <div className="wl-container">
        <div className="wl-section-head">
          <div className="wl-pill mb-2">
            <History className="w-4 h-4 text-rose-400" />
            <span>{t.badge}</span>
          </div>
          <h2>{t.historyTitle}</h2>
          <p>{t.historySubtitle}</p>
        </div>

        <div className="wl-results-card wl-history-surface">
          <div className="wl-results-head">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider block">{data.periodLabel}</span>
              <h3>{t.historyTitle}</h3>
            </div>
            <div className="wl-score">
              <span>{rows.length}</span>
              <span className="text-xs font-medium">{t.latestFive}</span>
            </div>
          </div>

          <div className="wl-history-list">
            {rows.map((row) => (
              <div key={row.issue} className="wl-history-row">
                <div className="flex flex-col min-w-0">
                  <span className="wl-history-issue">#{formatPeriodNumber(row.issue)}</span>
                  <span className="text-[11px] font-mono font-medium">IST {row.time}</span>
                </div>
                <span className={getBallClass(row.number)} aria-label={`Number ${row.number}`}>
                  {row.number}
                </span>
                <span className={`wl-tag ${row.size === 'Big' ? 'wl-tag-violet' : 'wl-tag-red'}`}>
                  {row.size === 'Big' ? t.big : t.small}
                </span>
                <div className="wl-history-colors">
                  {row.colors.map((color) => (
                    <span key={color} className={`wl-tag wl-tag-${color.toLowerCase()}`}>
                      {color === 'Green' ? t.green : color === 'Red' ? t.red : t.violet}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
