import React, { useState, useEffect } from 'react';
import { Flame, ArrowUp, Send, Mail, ShieldAlert } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';
import { ADMIN_CONTACT_EMAIL, TELEGRAM_JOIN_URL } from '../siteLinks';

interface FooterProps {
  language: Language;
}

export const Footer: React.FC<FooterProps> = ({ language }) => {
  const t = translations[language];
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="wl-footer relative">
      <div className="wl-container">
        <div className="wl-footer-grid">
          {/* Brand */}
          <div className="wl-footer-brand">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-md">
                <Flame className="w-5 h-5 fill-amber-300 text-amber-300" />
              </div>
              <span className="text-xl font-black text-white">
                Wingo <span className="text-rose-400">Pro</span>
              </span>
            </div>

            <p>{t.heroSubtitle}</p>

            <div className="wl-footer-contact">
              <span>
                <Mail className="w-4 h-4 text-indigo-400" />
                <a href={`mailto:${ADMIN_CONTACT_EMAIL}`}>{ADMIN_CONTACT_EMAIL}</a>
              </span>
            </div>

            <div className="wl-footer-social">
              <a href={TELEGRAM_JOIN_URL} target="_blank" rel="noreferrer noopener" aria-label="Telegram">
                <Send className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick links */}
          <div className="wl-footer-col">
            <h3>{t.quickLinks}</h3>
            <a href="#live-prediction">
              <span>›</span> {t.navSignals}
            </a>
            <a href="#draw-history">
              <span>›</span> {t.navHistory}
            </a>
            <a href="#rules-guide">
              <span>›</span> {t.navGuide}
            </a>
            <a href="#faq">
              <span>›</span> {t.navFaq}
            </a>
          </div>

          {/* Periods */}
          <div className="wl-footer-col">
            <h3>{t.periodsHeading}</h3>
            <a href="#live-prediction">
              <span>›</span> WinGo 30s
            </a>
            <a href="#live-prediction">
              <span>›</span> WinGo 1 Min
            </a>
          </div>

          {/* Telegram VIP */}
          <div className="wl-footer-col">
            <h3>{t.contactSupport}</h3>
            <a href={TELEGRAM_JOIN_URL} target="_blank" rel="noreferrer noopener">
              <span>›</span> {t.joinTelegram}
            </a>
            <div className="mt-4 p-3 rounded-xl bg-white/5 border border-white/10 text-xs text-slate-400">
              <span className="text-emerald-400 font-bold block mb-1">● 24/7 Live Sync</span>
              Synchronized to India Standard Time (IST, UTC+5:30)
            </div>
          </div>
        </div>

        {/* Disclaimer & note */}
        <div className="wl-footer-note">
          <p>{t.disclaimer}</p>
          <span>© {new Date().getFullYear()} {t.siteTitle}</span>
        </div>
      </div>

      {/* Floating Back to Top Button */}
      <button
        type="button"
        onClick={scrollToTop}
        className={`wl-floating-top ${showScrollTop ? 'is-visible' : ''}`}
        aria-label="Back to Top"
      >
        <ArrowUp className="w-5 h-5" />
      </button>
    </footer>
  );
};
