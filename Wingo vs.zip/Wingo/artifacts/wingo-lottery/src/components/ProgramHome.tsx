import React from 'react';
import { ArrowRight, BarChart3, Check, Clock3, Flame, Globe, Sparkles } from 'lucide-react';
import { Language, PeriodType } from '../types';
import './ProgramHome.css';

interface ProgramHomeProps {
  language: Language;
  onToggleLanguage: () => void;
  onSelectPeriod: (period: PeriodType) => void;
}

const content: Record<
  Language,
  {
    brandLine: string;
    switchLanguage: string;
    eyebrow: string;
    title: string;
    description: string;
    fastCycle: string;
    standardCycle: string;
    cycle30: string;
    cycle1m: string;
    description30: string;
    description1m: string;
    details: string[];
    enter30: string;
    enter1m: string;
    note: string;
  }
> = {
  en: {
    brandLine: 'Prediction programs',
    switchLanguage: 'हिन्दी',
    eyebrow: 'TWO LIVE DRAW CYCLES',
    title: 'Choose your prediction system',
    description: 'Select a draw cycle to open its live prediction workspace.',
    fastCycle: 'FAST CYCLE',
    standardCycle: 'STANDARD CYCLE',
    cycle30: 'Every 30 seconds',
    cycle1m: 'Every 1 minute',
    description30: 'A quick draw cycle with a live countdown, current signal, and recent results.',
    description1m: 'A steady one-minute cycle with a live countdown, current signal, and recent results.',
    details: ['Live countdown and B/S signal', 'Recent draw numbers', 'Big/Small trend history'],
    enter30: 'Enter 30s prediction',
    enter1m: 'Enter 1m prediction',
    note: 'Choose a cycle to continue to its prediction system.',
  },
  hi: {
    brandLine: 'प्रेडिक्शन प्रोग्राम',
    switchLanguage: 'English',
    eyebrow: 'दो लाइव ड्रॉ साइकल',
    title: 'अपना प्रेडिक्शन सिस्टम चुनें',
    description: 'लाइव प्रेडिक्शन वर्कस्पेस खोलने के लिए ड्रॉ साइकल चुनें।',
    fastCycle: 'तेज़ साइकल',
    standardCycle: 'स्टैंडर्ड साइकल',
    cycle30: 'हर 30 सेकंड',
    cycle1m: 'हर 1 मिनट',
    description30: 'लाइव काउंटडाउन, मौजूदा सिग्नल और हाल के नतीजों वाला तेज़ ड्रॉ साइकल।',
    description1m: 'लाइव काउंटडाउन, मौजूदा सिग्नल और हाल के नतीजों वाला एक मिनट का साइकल।',
    details: ['लाइव काउंटडाउन और बिग/स्मॉल सिग्नल', 'हाल के ड्रॉ नंबर', 'बिग/स्मॉल ट्रेंड हिस्ट्री'],
    enter30: '30s प्रेडिक्शन खोलें',
    enter1m: '1m प्रेडिक्शन खोलें',
    note: 'आगे बढ़ने के लिए एक साइकल चुनें।',
  },
};

export function ProgramHome({ language, onToggleLanguage, onSelectPeriod }: ProgramHomeProps) {
  const t = content[language];

  return (
    <div className="wl-program-home">
      <header className="wl-program-header">
        <div className="wl-program-brand">
          <span className="wl-program-brand-mark" aria-hidden="true">
            <Flame className="h-6 w-6" />
          </span>
          <span className="wl-program-brand-copy">
            <strong>
              Wingo <span>Pro</span>
            </strong>
            <small>{t.brandLine}</small>
          </span>
        </div>

        <button
          type="button"
          className="wl-program-language"
          onClick={onToggleLanguage}
          aria-label={language === 'en' ? 'Switch language to Hindi' : 'Switch language to English'}
        >
          <Globe className="h-4 w-4" />
          <span>{t.switchLanguage}</span>
        </button>
      </header>

      <main className="wl-program-content">
        <div className="wl-program-intro">
          <span className="wl-program-eyebrow">
            <Sparkles className="h-4 w-4" />
            {t.eyebrow}
          </span>
          <h1>{t.title}</h1>
          <p>{t.description}</p>
        </div>

        <div className="wl-program-options">
          <article className="wl-program-card wl-program-card--fast">
            <div className="wl-program-card-top">
              <span className="wl-program-icon wl-program-icon--fast">
                <Clock3 className="h-5 w-5" />
              </span>
              <span className="wl-program-cycle">{t.fastCycle}</span>
            </div>
            <div className="wl-program-card-heading">
              <h2>WinGo 30s</h2>
              <span className="wl-program-duration">{t.cycle30}</span>
            </div>
            <p className="wl-program-description">{t.description30}</p>
            <ul className="wl-program-details">
              {t.details.map((detail) => (
                <li key={detail}>
                  <Check className="h-4 w-4" />
                  <span>{detail}</span>
                </li>
              ))}
            </ul>
            <button
              type="button"
              className="wl-program-enter"
              onClick={() => onSelectPeriod('30s')}
            >
              <span>{t.enter30}</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </article>

          <article className="wl-program-card wl-program-card--standard">
            <div className="wl-program-card-top">
              <span className="wl-program-icon wl-program-icon--standard">
                <BarChart3 className="h-5 w-5" />
              </span>
              <span className="wl-program-cycle">{t.standardCycle}</span>
            </div>
            <div className="wl-program-card-heading">
              <h2>WinGo 1 Min</h2>
              <span className="wl-program-duration">{t.cycle1m}</span>
            </div>
            <p className="wl-program-description">{t.description1m}</p>
            <ul className="wl-program-details">
              {t.details.map((detail) => (
                <li key={detail}>
                  <Check className="h-4 w-4" />
                  <span>{detail}</span>
                </li>
              ))}
            </ul>
            <button
              type="button"
              className="wl-program-enter"
              onClick={() => onSelectPeriod('1m')}
            >
              <span>{t.enter1m}</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </article>
        </div>

        <p className="wl-program-note">
          <Clock3 className="h-4 w-4" />
          {t.note}
        </p>
      </main>

      <footer className="wl-program-footer">
        <span className="wl-program-footer-mark"><Flame className="h-4 w-4" /></span>
        <span>Wingo Pro</span>
      </footer>
    </div>
  );
}
