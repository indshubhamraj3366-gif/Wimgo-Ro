import React from 'react';
import { X } from 'lucide-react';
import { Language, PeriodType } from '../types';

interface ProfileModalProps {
  language: Language;
  period: PeriodType;
  resolvedCount: number;
  onClose: () => void;
}

export function ProfileModal({ language, period, resolvedCount, onClose }: ProfileModalProps) {
  const hindi = language === 'hi';

  return (
    <div className="wl-result-backdrop" role="presentation" onClick={onClose}>
      <section
        className="wl-profile-panel"
        role="dialog"
        aria-modal="true"
        aria-labelledby="wl-profile-title"
        onClick={(event) => event.stopPropagation()}
      >
        <button type="button" className="wl-profile-close" onClick={onClose} aria-label={hindi ? 'बंद करें' : 'Close profile'}>
          <X aria-hidden="true" />
        </button>
        <span className="wl-profile-avatar" aria-hidden="true">G</span>
        <p className="wl-result-kicker">WINGO PRO</p>
        <h2 id="wl-profile-title">{hindi ? 'अतिथि प्रोफ़ाइल' : 'Guest Profile'}</h2>
        <p className="wl-profile-note">{hindi ? 'यह प्रोफ़ाइल केवल इस ब्राउज़र सत्र में सक्रिय है।' : 'This profile is active for this browser session only.'}</p>
        <dl className="wl-profile-stats">
          <div><dt>{hindi ? 'चयनित गेम' : 'Selected game'}</dt><dd>WinGo {period}</dd></div>
          <div><dt>{hindi ? 'सत्यापित परिणाम' : 'Resolved results'}</dt><dd>{resolvedCount}</dd></div>
        </dl>
      </section>
    </div>
  );
}
