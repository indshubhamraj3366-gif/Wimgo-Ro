import React from 'react';
import { X } from 'lucide-react';
import { Language, PredictionLogEntry } from '../types';

interface PredictionLogModalProps {
  isOpen: boolean;
  onClose: () => void;
  entries: PredictionLogEntry[];
  language: Language;
}

export function PredictionLogModal({ isOpen, onClose, entries, language }: PredictionLogModalProps) {
  if (!isOpen) return null;
  const hindi = language === 'hi';

  return (
    <div className="wl-result-backdrop" role="presentation" onClick={onClose}>
      <section
        className="wl-log-panel"
        role="dialog"
        aria-modal="true"
        aria-labelledby="wl-log-title"
        onClick={(event) => event.stopPropagation()}
      >
        <header className="wl-log-header">
          <div>
            <p className="wl-result-kicker">WINGO PRO</p>
            <h2 id="wl-log-title">{hindi ? 'प्रेडिक्शन लॉग' : 'PREDICTION LOGS'}</h2>
          </div>
          <button type="button" className="wl-profile-close" onClick={onClose} aria-label={hindi ? 'बंद करें' : 'Close logs'}>
            <X aria-hidden="true" />
          </button>
        </header>
        <div className="wl-log-columns" aria-hidden="true">
          <span>{hindi ? 'पीरियड' : 'Period'}</span>
          <span>{hindi ? 'अनुमान' : 'Prediction'}</span>
          <span>{hindi ? 'वास्तविक' : 'Actual Result'}</span>
          <span>{hindi ? 'स्थिति' : 'Status'}</span>
          <span>{hindi ? 'समय' : 'Timestamp'}</span>
        </div>
        <div className="wl-log-list">
          {entries.length === 0 ? (
            <p className="wl-log-empty">{hindi ? 'इस सत्र में अभी कोई परिणाम नहीं है।' : 'No resolved results in this session yet.'}</p>
          ) : [...entries].reverse().map((entry) => (
            <div className="wl-log-row" key={`${entry.period}-${entry.timestamp}`}>
              <span>#{entry.period}</span>
              <span>{entry.prediction}</span>
              <span>{entry.actualResult}</span>
              <span className={entry.status === 'WIN' ? 'wl-log-win' : 'wl-log-loss'}>{entry.status}</span>
              <time dateTime={new Date(entry.timestamp).toISOString()}>
                {new Intl.DateTimeFormat(language === 'hi' ? 'hi-IN' : 'en', {
                  hour: '2-digit', minute: '2-digit', second: '2-digit',
                }).format(entry.timestamp)}
              </time>
            </div>
          ))}
        </div>
        <p className="wl-log-session-note">
          {hindi ? 'लॉग केवल वर्तमान सत्र में रखे जाते हैं और रीफ़्रेश पर साफ़ हो जाते हैं।' : 'Session-only records. Logs clear when this page is refreshed.'}
        </p>
      </section>
    </div>
  );
}
