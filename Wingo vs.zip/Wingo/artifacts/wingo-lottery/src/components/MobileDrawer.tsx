import React from 'react';
import {
  X,
  Send,
  Globe,
  Flame,
  Clock,
  Check,
  House,
  UserRound,
  Mail,
} from 'lucide-react';
import { Language, PeriodType } from '../types';
import { translations } from '../translations';
import { ADMIN_CONTACT_EMAIL, TELEGRAM_JOIN_URL } from '../siteLinks';

interface MobileDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onToggleLanguage: () => void;
  currentPeriod: PeriodType;
  onSelectPeriod: (p: PeriodType) => void;
  onOpenPredictionLog: () => void;
  onOpenProfile: () => void;
  onHome: () => void;
  countdownMap: Record<PeriodType, string>;
}

export const MobileDrawer: React.FC<MobileDrawerProps> = ({
  isOpen,
  onClose,
  language,
  onToggleLanguage,
  currentPeriod,
  onSelectPeriod,
  onOpenPredictionLog,
  onOpenProfile,
  onHome,
  countdownMap,
}) => {
  const t = translations[language];
  const periods: PeriodType[] = ['30s', '1m'];

  if (!isOpen) return null;

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 bg-slate-950/60 z-50 backdrop-blur-xs transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Drawer */}
      <div className="wl-drawer-panel fixed inset-y-0 left-0 z-50 flex w-[min(22rem,88vw)] flex-col overflow-y-auto overscroll-contain p-5 pt-[calc(env(safe-area-inset-top)+1.25rem)] pb-[calc(env(safe-area-inset-bottom)+1.25rem)] animate-in slide-in-from-left duration-250">
        {/* Head */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-md">
              <Flame className="w-5 h-5 fill-amber-300 text-amber-300" />
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-black text-slate-900 leading-none">
                Wingo <span className="text-rose-500">Pro</span>
              </span>
              <span className="text-[10px] font-bold text-slate-400 uppercase mt-0.5">
                {t.threeDotOptions}
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-lg flex items-center justify-center text-slate-500 hover:bg-slate-100 transition-colors"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Section 1: Period Selection */}
        <div className="pt-4 pb-2 border-b border-slate-100">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-black text-slate-800 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-indigo-600" />
              <span>{t.switchPeriod}</span>
            </span>
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-500">
              IST Sync
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {periods.map((p) => {
              const isActive = currentPeriod === p;
              const info = t.periods[p];
              const time = countdownMap[p] || '00:00';

              return (
                <button
                  key={p}
                  type="button"
                  onClick={() => {
                    onSelectPeriod(p);
                    onClose();
                  }}
                  className={`p-3 rounded-2xl text-left border transition-all ${
                    isActive
                      ? 'bg-indigo-50/70 border-indigo-300 shadow-xs'
                      : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-xs font-black ${
                        isActive ? 'text-indigo-700' : 'text-slate-800'
                      }`}
                    >
                      {info.name}
                    </span>
                    {isActive && <Check className="w-3.5 h-3.5 text-indigo-600" />}
                  </div>
                  <span className="text-[11px] font-mono font-bold text-slate-500 block mt-1">
                    {time}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        <nav className="flex flex-col gap-1 py-4" aria-label={language === 'hi' ? 'मुख्य मेन्यू' : 'Main menu'}>
          <button type="button" onClick={() => { onHome(); onClose(); }} className="wl-drawer-link">
            <House aria-hidden="true" /><span>{language === 'hi' ? 'होम' : 'Home'}</span>
          </button>
          <button type="button" onClick={() => { onClose(); onOpenPredictionLog(); }} className="wl-drawer-link">
            <Clock aria-hidden="true" /><span>{language === 'hi' ? 'प्रेडिक्शन लॉग' : 'Prediction Logs'}</span>
          </button>
          <button type="button" onClick={() => { onClose(); onOpenProfile(); }} className="wl-drawer-link">
            <UserRound aria-hidden="true" /><span>{language === 'hi' ? 'प्रोफ़ाइल' : 'Profile'}</span>
          </button>
          <a className="wl-drawer-link" href={`mailto:${ADMIN_CONTACT_EMAIL}`}>
            <Mail aria-hidden="true" /><span>{language === 'hi' ? 'एडमिन संपर्क' : 'Admin Contact'}</span>
          </a>
          <a className="wl-drawer-link" href={TELEGRAM_JOIN_URL} target="_blank" rel="noreferrer noopener">
            <Send aria-hidden="true" /><span>{language === 'hi' ? 'TG से जुड़ें' : 'TG Join'}</span>
          </a>
        </nav>

        {/* Drawer Bottom Actions */}
        <div className="mt-auto flex flex-col gap-2.5 pt-4 border-t border-slate-100">
          <button
            type="button"
            onClick={() => {
              onToggleLanguage();
              onClose();
            }}
            className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl border border-indigo-200 bg-indigo-50/60 text-indigo-700 font-extrabold text-xs hover:bg-indigo-100 transition-colors"
          >
            <Globe className="w-4 h-4 text-indigo-600" />
            <span>Switch to {language === 'en' ? 'हिन्दी (Hindi)' : 'English'}</span>
          </button>

        </div>
      </div>
    </>
  );
};
