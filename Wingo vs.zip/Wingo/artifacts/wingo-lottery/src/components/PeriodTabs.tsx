import React from 'react';
import { Clock, BarChart3 } from 'lucide-react';
import { Language, PeriodType } from '../types';
import { translations } from '../translations';

interface PeriodTabsProps {
  currentPeriod: PeriodType;
  onSelectPeriod: (period: PeriodType) => void;
  language: Language;
  countdownMap: Record<PeriodType, string>;
  onOpenPredictionLog?: () => void;
}

export const PeriodTabs: React.FC<PeriodTabsProps> = ({
  currentPeriod,
  onSelectPeriod,
  language,
  countdownMap,
  onOpenPredictionLog,
}) => {
  const t = translations[language];
  const periods: PeriodType[] = ['30s', '1m'];

  return (
    <div className="w-full">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <h3 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
          <Clock className="w-5 h-5 text-indigo-600" />
          <span>{t.periodSwitchTitle}</span>
        </h3>

        <div className="flex items-center gap-2">
          {onOpenPredictionLog && (
            <button
              type="button"
              onClick={onOpenPredictionLog}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-black text-xs shadow-md shadow-indigo-600/20 hover:scale-[1.02] transition-all cursor-pointer"
            >
              <BarChart3 className="w-4 h-4" />
              <span>{language === 'hi' ? 'प्रेडिक्शन लॉग' : 'PREDICTION LOGS'}</span>
              <span className="text-[10px] px-1.5 py-0.5 bg-amber-300 text-slate-950 font-black rounded-md">
                LOG
              </span>
            </button>
          )}

          <span className="text-xs font-bold text-slate-500 bg-white px-3 py-1.5 rounded-xl border border-slate-200 shadow-2xs hidden lg:inline">
            IST 24/7 Live
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-3xl">
        {periods.map((p) => {
          const isActive = currentPeriod === p;
          const info = t.periods[p];
          const time = countdownMap[p] || '00:00';

          return (
            <button
              key={p}
              type="button"
              onClick={() => onSelectPeriod(p)}
              className={`wl-period-card transition-all text-left relative overflow-hidden group ${
                isActive ? 'is-active ring-2 ring-indigo-500 ring-offset-1' : 'hover:border-indigo-300'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className={`text-base font-black ${isActive ? 'text-indigo-600' : 'text-slate-800'}`}>
                  {info.name}
                </span>
                <span
                  className={`text-xs font-mono font-bold px-2 py-0.5 rounded-md ${
                    isActive
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-100 text-slate-600 group-hover:bg-indigo-50 group-hover:text-indigo-600'
                  }`}
                >
                  {time}
                </span>
              </div>
              <small className="text-xs text-slate-500 font-medium line-clamp-1 mt-1.5">
                {info.desc}
              </small>

              {isActive && (
                <div className="absolute top-0 right-0 w-2 h-2 bg-indigo-600 rounded-bl-sm" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
