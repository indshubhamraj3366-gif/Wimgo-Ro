import { PeriodType } from '../types';

export const PERIOD_SECONDS: Record<PeriodType, number> = {
  '30s': 30,
  '1m': 60,
};

export const PERIOD_NAMES: Record<PeriodType, string> = {
  '30s': 'WinGo 30s',
  '1m': 'WinGo 1 Min',
};

// Calculate exact IST seconds left
export function getSecondsLeft(totalSeconds: number): number {
  totalSeconds = Number(totalSeconds || 60);
  const now = new Date();
  const utc = now.getTime() + now.getTimezoneOffset() * 60000;
  const india = new Date(utc + 330 * 60000); // UTC+5:30
  const secondsToday =
    india.getHours() * 3600 +
    india.getMinutes() * 60 +
    india.getSeconds();

  const left = totalSeconds - (secondsToday % totalSeconds);
  return left === totalSeconds ? 0 : left;
}

export function formatCountdown(seconds: number): string {
  const safe = Math.max(0, Math.floor(seconds || 0));
  const minutes = Math.floor(safe / 60);
  const remain = safe % 60;
  return String(minutes).padStart(2, '0') + ':' + String(remain).padStart(2, '0');
}

export function formatPeriodNumber(issue: string): string {
  const digits = String(issue ?? '').replace(/\D/g, '');
  return digits.slice(-4);
}
